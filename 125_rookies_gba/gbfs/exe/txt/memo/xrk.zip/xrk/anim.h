#ifndef _ANIM_H_
#define _ANIM_H_
typedef struct _anim_t {
  Pixmap pixmap;
  int width, height;
  int vheight;
  int top, bottom, speed;
  int current;
  XColor color[16];
  XtIntervalId timer;
} *anim_t;

extern void expand_animation(Widget, int, int, int, int);
extern void free_animation(Widget);
#endif
