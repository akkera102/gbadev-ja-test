#include <X11/Intrinsic.h>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <X11/Xlib.h>
#include "mig.h"
#include <assert.h>

#define LINENO 10
#define MAXWIDTH 640

int data_b_1004[][2] = {
  {  0,   0}, { -2,   0}, {  0,  -1}, {  2,  -1},
  { -2,  -1}, {  4,  -1}, {  2,  -2}, { -4,  -1},
  { -2,  -2}, {  0,  -2}, {  0,  -8}, { -6,  -1},
  {  6,  -1}, {-16,   0}, {  8,  -2}, { -4,   0},
};

int data_b_1024[][2] = {
  {  3,   1}, {  4,   2}, {  5,   6}, {  7,   8},
  {  9,  10}, { -9,  11}, { 12,  13}, { -1,  -2},
  { -3,  -4}, { -5,  -6}, { -7,  -8}, {-10, -11},
  {-12, -13}, {-14, -15},
};

int data_b_105C[][2] = {
  { 26,   1}, {  3,   2}, { -3,   4}, {  8,   6},
  { -4,   5}, { 10,   7}, { 14,   9}, { 29,  13},
  { -5,  11}, { -7,  15}, { 16,  12}, { -6,  27},
  {-17,  22}, { 21,  17}, { -8,  28}, { 30,  18},
  { 19,  20}, { 36,  25}, { 31,  32}, {-19,  33},
  {-20,  34}, {-21,  35}, { 23,  24}, { 37,  38},
  { 39,  40}, { 41,  42}, { -1,  -2}, { -9, -10},
  {-11, -12}, {-13, -14}, {-15, -16}, {-18, -44},
  {-22, -23}, {-24, -25}, {-26, -27}, {-28, -29},
  {-30, -31}, {-32, -33}, {-34, -35}, {-36, -37},
  {-38, -39}, {-40, -41}, {-42, -43},
};
int data_b_1108[][2] = {
  {  0,   1}, { -1,   2}, { -2,   3}, { 11,   4},
  { -3,   5}, { -6,   6}, {  7,   8}, { -7,   9},
  { -8,  10}, { -9,  12}, {-10,  13}, { -4,  -5},
  {-11,  14}, {-12, -15}, {-13, -14},
};

char col_tab[16][16] = {
  {0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1},
  {1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2},
  {2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3},
  {3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4},
  {4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5},
  {5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6},
  {6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8, 7},
  {7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9, 8},
  {8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10, 9},
  {9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11, 10},
  {10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12, 11},
  {11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13, 12},
  {12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14, 13},
  {13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15, 14},
  {14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 15},
  {15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0},
};

typedef struct {
  unsigned char dot[2];
} dots_t;

typedef dots_t line_t[MAXWIDTH];

line_t *line[LINENO];

int mig_x, mig_y;
int mig_width, mig_height;

static int bitpp;

static int getbit(FILE *fp)
{
  static char c;
  int p;

  if (bitpp <= 0) {
    bitpp = 8;
    fread(&c, 1, 1, fp);
  }
  p = --bitpp;
  return (c & (1 << p)) ? 1 : 0;
}

int poi(FILE *fp, int (*p)[2])
{
  int c;
  int cur, next;

  cur = next = 0;
  while (1) {
    c = getbit(fp);
    next = p[cur][c];
    if (next <= 0)
      return -next;
    cur = next;
  }
}

void rotate_row(int p, int q)
{
  int i;
  int c;

  c = col_tab[p][q];
  for (i = q; i > 1; i--)
    col_tab[p][i] = col_tab[p][i-1];
  col_tab[p][1] = c;
}

int one_token(FILE *fp, int s)
{
  char c;
  int r;

  c = poi(fp, data_b_1108);
  if (c == 0)
    r = s;
  else {
    rotate_row(s, c);
    r = col_tab[s][1];
  }
  return r;
}

void expand_2x2(FILE *fp)
{
  int p;
  dots_t left, upper_l, upper_r, cur_l, cur_r;

  if (mig_x == 0)
    left = (*line[1])[mig_width - 1];
  else
    left = (*line[0])[mig_x - 1];
  upper_l = (*line[1])[mig_x];
  upper_r = (*line[1])[mig_x + 1];

  if (upper_l.dot[0] == upper_l.dot[1])
    p = upper_l.dot[0];
  else
    p = left.dot[0];
  cur_l.dot[0] = one_token(fp, p);
  if (upper_r.dot[0] == upper_r.dot[1])
    p = upper_r.dot[0];
  else
    p = cur_l.dot[0];
  cur_r.dot[0] = one_token(fp, p);
  if (upper_l.dot[1] == cur_l.dot[0])
    p = upper_l.dot[1];
  else
    p = left.dot[1];
  cur_l.dot[1] = one_token(fp, p);
  if (upper_r.dot[1] == cur_r.dot[0])
    p = upper_r.dot[1];
  else
    p = cur_l.dot[1];
  cur_r.dot[1] = one_token(fp, p);
  (*line[0])[mig_x] = cur_l;
  (*line[0])[mig_x + 1] = cur_r;
  mig_x += 2;
}

void expand_chunk(FILE *fp)
{
  int p, q;
  int d;
  int dx, dy;
  int x0, x1;
  int i;

  p = poi(fp, data_b_1024);
  q = poi(fp, data_b_105C);
  if (q == 0x2c) {
    while (1) {
      int c0, c1, c2, c3;
      c0 = getbit(fp);
      c1 = getbit(fp);
      c2 = getbit(fp);
      c3 = getbit(fp);
      d = c0 * 8 + c1 * 4 + c2 * 2 + c3;
      if (d != 0xf)
	break;
      q += 0xf;
    }
    q += d;
  }
  x0 = x1 = mig_x;
  dx = data_b_1004[p][0]; dy = -data_b_1004[p][1];
  x0 += dx;
  for (i = 0; i < q; i++) {
    if (x0 < 0) {
      (*line[0])[x1] = (*line[dy+1])[mig_width+x0];
    } else if (x0 >= mig_width) {
      (*line[0])[x1] = (*line[dy-1])[x0-mig_width];
    } else {
      (*line[0])[x1] = (*line[dy])[x0];
    }
    if (x0 + 1 < 0) {
      (*line[0])[x1+1] = (*line[dy+1])[mig_width+x0+1];
    } else if (x0 + 1 >= mig_width) {
      (*line[0])[x1+1] = (*line[dy-1])[x0+1-mig_width];
    } else {
      (*line[0])[x1+1] = (*line[dy])[x0+1];
    }
    x0 += 2; x1 += 2;
  }
  mig_x += q * 2;
}

void output_line(cg_t cg)
{
  int i;
  line_t *l0;
  unsigned char *data;
  unsigned char up, down;

  l0 = line[0];
  data = cg->ximage->data;
  for (i = 0; i < mig_width; i++) {
    up = (*l0)[i].dot[0];
    down = (*l0)[i].dot[1];
    data[mig_y * 2 * mig_width + i] = up;
    data[(mig_y * 2 + 1) * mig_width + i] = down;
  }
}

static void expand_file(FILE *fp, cg_t cg)
{
  int i, j;

  mig_x = mig_y = 0;
  bitpp = 0;

  for (i = 0; i < 16; i++)
    for (j = 0; j < 16; j++)
      col_tab[i][j] = (i - j + 16) % 16;

  while (1) {
    if (getbit(fp) == 0)
      expand_2x2(fp);
    else
      expand_chunk(fp);
    if (mig_x >= mig_width) {
      line_t *l;
      output_line(cg);
      l = line[LINENO-1];
      for (i = LINENO - 1; i > 0; i--)
	line[i] = line[i-1];
      line[0] = l;
      for (j = 0; j < MAXWIDTH; j++) {
	(*l)[j].dot[0] = 0;
	(*l)[j].dot[1] = 0;
      }
      mig_x = 0;
      mig_y++;
    }
    if (mig_y >= mig_height)
      break;
  }
}

void free_picture(cg_t cg)
{
  if (cg != NULL)
    XDestroyImage(cg->ximage);
  free(cg);
}

cg_t expand_picture(Widget rw, char *filename)
{
  FILE *fp;
  char magic[3];
  char palette_src[0x18];
  unsigned char c[2];
  int i, j;
  int size;
  cg_t cg;
  Display *display;
  Visual *visual;

  if ((fp = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "couldn't find MIG file \"%s\"\n", filename);
    exit(1);
  }
  fread(magic, sizeof(magic), 1, fp);
  if (memcmp(magic, "MIG", sizeof(magic))) {
    fprintf(stderr, "this is NOT a mig file: \"%s\"\n", filename);
    fclose(fp);
    exit(1);
  }
  fread(c, sizeof(c), 1, fp);
  mig_width = c[1] * 0x100 + c[0];
  fread(c, sizeof(c), 1, fp);
  mig_height = c[1] * 0x100 + c[0];
  fread(palette_src, sizeof(palette_src), 1, fp);

  cg = (cg_t)malloc(sizeof(struct _cg_t));
  cg->width = mig_width;
  cg->height = mig_height * 2;
  size = cg->width * cg->height;
  display = XtDisplay(rw);
  visual = DefaultVisual(display, DefaultScreen(display));
  cg->ximage = XCreateImage(display, visual, 8, ZPixmap,
			    0, 0, mig_width, mig_height * 2, 8, 0);
  cg->ximage->data = (char *)malloc(size);
  memset(cg->ximage->data, 0, size);
  XInitImage(cg->ximage);

  for (i = 0; i < sizeof(palette_src); i++) {
    cg->palette[2 * i] = (palette_src[i] >> 4) & 0xf;
    cg->palette[2 * i + 1] = palette_src[i] & 0xf;
				/* (p[0], p[1], p[2]) = (G, R, B) */
  }
  for (i = 0; i < LINENO; i++) {
    line[i] = (line_t *)malloc(sizeof(line_t));
    for (j = 0; j < MAXWIDTH; j++) {
      (*line[i])[j].dot[0] = 0;
      (*line[i])[j].dot[1] = 0;
    }
  }

  expand_file(fp, cg);

  for (i = 0; i < LINENO; i++)
    free(line[i]);
  fclose(fp);
  return cg;
}
