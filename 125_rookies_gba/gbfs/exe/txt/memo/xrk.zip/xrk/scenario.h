#ifndef _SCENARIO_H_
#define _SCENARIO_H_

int scenario(RookiesWidget);
void scenario_initialize(void);
void timeout_handler(Widget);

#define EMPTY 0x0
#define UP 0x1
#define DOWN 0x2
#define LEFT 0x4
#define RIGHT 0x8
#define CONFIRM 0x10
#define CANCEL 0x20
#define ESCAPE 0x40
#define MOTION 0x8000

#define CONTINUE 0
#define YIELD 1
#define SLEEP 2

#endif
