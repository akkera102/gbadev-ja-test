#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "jis.h"
#include "exp.h"

unsigned char *output;

char *embedded_string[] = {
  "�ߤ��Ҥ�",
  "�ߤ��Ҥ�",
  "�ٹ路�Ƥ����ܤΰ������硼�ȥ��åȤΥ��磻�����ҹ���",
  "�ٹ路�Ƥ����ܤ��������ʤⰭ�����硼�ȥ��åȤν��ҹ���",
  "�ٹ路�Ƥ������ʤ��������硼�ȥ��åȤν��ҹ���",
  "���վ�",
  "�շ�",
  "�ӣ��ãˣ�",
  "������",
  "ͭ�Ͻ人",
  "Ȩ¼������",
  "������̼",
  "����",
  "�Ӵ�",
  "����",
  "�Ҥ���",
  "Τ��",
  "����",
  "����",
  "˾��",
  "ͳ����",
  "��Ĺ",
  "����",
  "����",
  "����",
  "�ܥ�",
  "�ۻ�",
};

void arithmetics(int op, int x, int y)
{
  switch (op) {
  case 0:			/* load immediate */
    printf("val[%d] = %d\n", x, y);
    break;
  case 1:			/* add immediate */
    printf("val[%d] += %d\n", x, y);
    break;
  case 2:			/* sub immediate */
    printf("val[%d] -= %d\n", x, y);
    break;
  case 3:			/* mul immediate */
    printf("val[%d] *= %d\n", x, y);
    break;
  case 4:			/* honto ha wari-zan? */
    printf("val[%d] /= %d\n", x, y);
    break;
  case 5:			/* mod immediate */
    printf("val[%d] %%= %d\n", x, y);
    break;
  case 6:			/* hmm... rand?*/
    printf("val[%d] = rand() %% %d\n", x, y);
    break;
  case 7:			/* mov */
    printf("val[%d] = val[%d]\n", x, y);
    break;
  case 8:			/* add */
    printf("val[%d] += val[%d]\n", x, y);
    break;
  case 9:			/* sub */
    printf("val[%d] -= val[%d]\n", x, y);
    break;
  case 0xa:			/* mul */
    printf("val[%d] *= val[%d]\n", x, y);
    break;
  case 0xb:			/* koremo wari-zan ? */
    printf("val[%d] /= val[%d]\n", x, y);
    break;
  case 0xc:			/* mod */
    printf("val[%d] %%= val[%d]\n", x, y);
    break;
  case 0xd:			/* hmm... rand??*/
    printf("val[%d] = rand() %% val[%d]\n", x, y);
    break;
  }
}

void jump(int x)
{
  printf("goto loc_%04X\n", x);
}

void exit_prg(int x)
{
  printf("exit(%d)\n", x);
}

void jal(int x)
{
  printf("call sub_%04X\n", x);
}

void retn(void)
{
  printf("return\n");
}

void branch(int op, int x, int y, int z)
{
  switch(op) {
  case 1:			/* je immediate */
    printf("if (val[%d] != %d) goto loc_%04X\n",
	   x, y, z);
    break;
  case 2:			/* jne immediate */
    printf("if (val[%d] == %d) goto loc_%04X\n",
	   x, y, z);
    break;
  case 3:			/* jg immediate */
    printf("if (val[%d] <= %d) goto loc_%04X\n",
	   x, y, z);
    break;
  case 4:			/* jl immediate */
    printf("if (val[%d] >= %d) goto loc_%04X\n",
	   x, y, z);
    break;
  case 5:			/* je */
    printf("if (val[%d] != val[%d]) goto loc_%04X\n",
	   x, y, z);
    break;
  case 6:			/* jne */
    printf("if (val[%d] == val[%d]) goto loc_%04X\n",
	   x, y, z);
    break;
  case 7:			/* jg */
    printf("if (val[%d] <= val[%d]) goto loc_%04X\n",
	   x, y, z);
    break;
  case 8:			/* jl */
    printf("if (val[%d] >= val[%d]) goto loc_%04X\n",
	   x, y, z);
    break;
  }
}

void draw_mig(int x, char *p)
{
  printf("draw_migfile(%d, \"%s\")\n", x, p);
}

void exec_file(char *p)
{
  printf("exec(\"%s\")\n", p);
}

void menu(int x, int y, char *items[])
{
  int i;

  printf("menu(%d, &val[%d], ", x, y);
  for (i = 0; i < x; i++) {
    printf("\"%s\"", items[i]);
    if (i == x - 1)		/* last item */
      printf(")\n");
    else
      printf(", ");
  }
}

void copy_sub_to_main(int x1, int y1, int x2, int y2)
{
  printf("copy_sub_to_main(%d, %d, %d, %d)\n", x1, y1, x2, y2);
}

void fill_rectangle(int x1, int y1, int x2, int y2, int color)
{
  printf("fill_rectangle(%d, %d, %d, %d, %d)\n",
	 x1, y1, x2, y2, color);
}

void clear_75(int x1, int y1, int x2, int y2)
{
  printf("clear_75(%d, %d, %d, %d)\n", x1, y1, x2, y2);
}

void set_xy(int x, int y)
{
  printf("set_xy(%d, %d)\n", x, y);
}

void play_bgm(char *p)
{
  printf("play_bgm(\"%s\")\n", p);
}

void refer_str(int x)
{
  if (x == 0)
    printf("refer_string(%d) = %s\n", x, embedded_string[x]);
  else
    printf("refer_string(%d) = ��%s��\n", x, embedded_string[x]);
}

void make_delay(int x)
{
  printf("delay(%d)\n", x);
}

void int_60_0(void)
{
  printf("int_60_0()\n");
}

void int_60_1(void)
{
  printf("int_60_1()\n");
}

void int_60_0D(void)
{
  printf("int_60_0D()\n");
}

void int_60_1A(void)
{
  printf("int_60_1A()\n");
}

void int_60_1B(void)
{
  printf("int_60_1B()\n");
}

void int_60_2_0(int x)
{
  printf("int_60_2_0(%d)\n", x);
}

void int_60_2_1(int x)
{
  printf("int_60_2_1(%d)\n", x);
}

void int_60_0C(int x)
{
  printf("int_60_0C(%d)\n", x);
}

void int_60_19(int x)
{
  printf("int_60_19(%d)\n", x);
}

void change_diskette(int x)
{
  printf("change_diskette(%d)\n", x);
}

void set_palette(void)
{
  printf("set_palette()\n");
}

void make_check_point(void)
{
  printf("make_check_point()\n");
}

void save_load_menu(void)
{
  printf("save_load_menu()\n");
}

void free_ani_data(void)
{
  printf("free_ani_data()\n");
}

void define_dialog_box(int x1, int y1, int x2, int y2)
{
  printf("define_dialog_box(%d, %d, %d, %d)\n", x1, y1, x2, y2);
}

void newline(void)
{
  printf("newline()\n");
}

void set_text_attribute(int x)
{
  printf("set_text_attribute(%d)\n", x);
}

void enable_system_menu(void)
{
  printf("enable_system_menu()\n");
}

void disable_system_menu(void)
{
  printf("disable_system_menu()\n");
}

void wait_for_key(void)
{
  printf("wait_for_key()\n");
}

void fade_in_black(int x)
{
  printf("fade_in_black(%d)\n", x);
}

void fade_out_black(int x)
{
  printf("fade_out_black(%d)\n", x);
}

void fade_out_white(int x)
{
  printf("fade_out_white(%d)\n", x);
}

void fade_in_white(int x)
{
  printf("fade_in_white(%d)\n", x);
}

void fancy_clear(void)
{
  printf("fancy_clear()\n");
}

void open_curtain(void)
{
  printf("open_curtain()\n");
}

void close_curtain(void)
{
  printf("close_curtain()\n");
}

void show_prompt(void)
{
  printf("show_prompt()\n");
}

void hide_prompt(void)
{
  printf("hide_prompt()\n");
}

void no_timeout_confirm(void)
{
  printf("no_timeout_confirm()\n");
}

void timeout_confirm(void)
{
  printf("timeout_confirm()\n");
}

void input_name(void)
{
  printf("input_name()\n");
}

void change_destination_and_esc()
{
  printf("change_destination_and_esc()\n");
}

void change_destination_and_esc_to_default()
{
  printf("change_destination_and_esc_to_default()\n");
}

void save_hoehoe_dat(int x)
{
  printf("save_hoehoe_dat(%d)\n", x);
}

void setup_zurizuri(int f, char *fstr, int s, char *sstr)
{
  printf("setup_zurizuri(%d, \"%s\", %d, \"%s\")\n",
	 f, fstr, s, sstr);
}

void zurizuri_scroll(void)
{
  printf("zurizuri_scroll()\n");
}

void scroll_up_two_screen(void)
{
  printf("scroll_up_two_screen()\n");
}

void run_dos_prg(char *cmd)
{
  printf("run_dos_prg(\"%s\")\n", cmd);
}

void read_idxfile(char *s)
{
  printf("read_idxfile(\"%s\")\n", s);
}

void read_pixfile(char *s)
{
  printf("read_pixfile(\"%s\")\n", s);
}

int func_00(int ip)
{
  exit_prg(output[ip + 1]);
  return 2;
}

int func_01(int ip)
{
  newline();			/* wait for input */
  return 1;
}

int func_02(int ip)
{
  int j;

  draw_mig(output[ip + 1], output + ip + 2);
  for (j = 2; output[ip + j] != '\0'; j++);

  return j + 1;
}

int func_03(int ip)
{
  int x;

  x = output[ip + 2] << 8 | output[ip + 1];
  jump(x);
  return 3;
}

int func_04(int ip)
{
  int x;

  x = output[ip + 2] << 8 | output[ip + 1];
  jal(x);
  return 3;
}

int func_05(int ip)
{
  char **menu_items;
  int end, ind, len;
  int i;
  int c;

  menu_items = (char **)calloc(sizeof(char *), output[ip + 1]);
  ind = ip + 3;
  for (i = 0; i < output[ip + 1]; i++) {
    len = 0;
    while (output[ind + len] != 1)
      len += 2;
    len++;
    menu_items[i] = (char *)malloc(len);
    menu_items[i][0] = '\0';
    ind += len;
  }
  end = ind;
  ind = ip + 3;
  for (i = 0; i < output[ip + 1]; i++) {
    len = 0;
    while (output[ind + len] != 1) {
      c = jis2euc(output[ind + len + 1], output[ind + len]);
      menu_items[i][len + 1] = c & 0xff;
      menu_items[i][len] = (c >> 8) & 0xff;
      len += 2;
    }
    menu_items[i][len] = '\0';
    len++;
    ind += len;
  }

  menu(output[ip + 1], output[ip + 2], menu_items);

  for (i = 0; i < output[ip + 1]; i++)
    free(menu_items[i]);
  free(menu_items);
  return end - ip;
}

int func_06(int ip)
{
  int j;
  int first_num, second_num;
  unsigned char *first_str, *second_str;

  first_num = output[ip + 1];
  first_str = output + ip + 2;
  for (j = 2; output[ip + j] != '\0'; j++);
  j++;
  second_num = output[ip + j];
  second_str = output + ip + j + 1;
  for (j += 2; output[ip + j] != '\0'; j++);
  j++;
  setup_zurizuri(first_num, first_str, second_num, second_str);
  return j;
}

int func_07(int ip)
{
  switch (output[ip + 1]) {
  case 1:
    zurizuri_scroll();
    break;
  case 2:
    scroll_up_two_screen();
    break;
  }
  return 2;
}

int func_08(int ip)
{
  free_ani_data();
  return 1;
}

int func_09(int ip)
{
  int op, x, y;

  op = output[ip + 2];
  x = output[ip + 1];
  y = output[ip + 3];
  arithmetics(op, x, y);
  return 4;
}

int func_0a(int ip)
{
  int op;
  int x, y, z;

  op = output[ip + 2];
  x = output[ip + 1];
  y = output[ip + 3];
  z = output[ip + 5] << 8 | output[ip + 4];
  branch(op, x, y, z);
  return 6;
}

int func_0b(int ip)
{
  int x, y;

  x = output[ip + 2] << 8 | output[ip + 1];
  y = output[ip + 4] << 8 | output[ip + 3];
  set_xy(x, y);
  return 5;
}

int func_0c(int ip)
{
  define_dialog_box(output[ip + 1],
		    output[ip + 2],
		    output[ip + 3],
		    output[ip + 4]);
  return 5;
}

int func_0d(int ip)
{
  switch (output[ip + 1]) {
  case 0:
    show_prompt();
    break;
  case 1:
    hide_prompt();
    break;
  case 2:
    no_timeout_confirm();
    break;
  case 3:
    timeout_confirm();
    break;
  }
  return 2;
}

int func_0e(int ip)
{
  int j;
  exec_file(output + ip + 1);
  for (j = 1; output[ip + j] != '\0'; j++);
  return j + 1;
}

int func_0f(int ip)
{
  int j;
  int r;

  r = 0;
  switch (output[ip + 1]) {
    /* (str) */
  case 0:
    play_bgm(output + ip + 2);
    for (j = 2; output[ip + j] != '\0'; j++);
    r = j + 1;
    break;
    /* (void) */
  case 1:
    int_60_0();
    r = 2;
    break;
  case 2:
    int_60_1();
    r = 2;
    break;
  case 7:
    int_60_0D();
    r = 2;
    break;
  case 8:
    int_60_1A();
    r = 2;
    break;
  case 9:
    int_60_1B();
    r = 2;
    break;
    /* (char) */
  case 3:
    int_60_2_0(output[ip + 2]);
    r = 3;
    break;
    /* (char) */
  case 4:
    int_60_2_1(output[ip + 2]);
    r = 3;
    break;
    /* (char) */
  case 5:
    int_60_0C(output[ip + 2]);
    r = 3;
    break;
  case 6:
    int_60_19(output[ip + 2]);
    r = 3;
    break;
  }
  return r;
}

int func_10(int ip)
{
  wait_for_key();
  return 1;
}

int func_11(int ip)
{
  int op;
  int speed;
  op = output[ip + 1];
  speed = output[ip + 2];
  switch (op) {
  case 1:			/* fade-in from black*/
    fade_in_black(speed);
    break;
  case 2:			/* fade-out to black*/
    fade_out_black(speed);
    break;
  case 3:			/* fade out to white */
    fade_out_white(speed);
    break;
  case 4:			/* fade in from white */
    fade_in_white(speed);
    break;
  case 5:			/* fancy clear */
    open_curtain();
    break;
  case 6:			/* fancy clear */
    close_curtain();
    break;
  default:
    break;
  }

  return 3;
}

int func_12(int ip)
{
  int j;

  run_dos_prg(output + ip + 1);
  for (j = 1; output[ip + j] != '\0'; j++);
  return j + 1;
}

int func_13(int ip)
{
  set_text_attribute(output[ip + 1]);
  return 2;
}

int func_14(int ip)	/* idx */
{
  int j;
  read_idxfile(output + ip + 1);
  for (j = 1; output[ip + j] != '\0'; j++);
  return j + 1;
}

int func_15(int ip)	/* pix */
{
  int j;
  read_pixfile(output + ip + 1);
  for (j = 1; output[ip + j] != '\0'; j++);
  return j + 1;
}

int func_16(int ip)
{
  int r;
  int i;
  char buf[0x100];
  int w, x, y, z;

  r = 0;
  switch (output[ip + 1]) {
    /* (char, char, char, char, ...) */
  case 0: case 1:
    i = 0;
    if (output[ip + 2] < output[ip + 3]) {
      for (i = 0; i < output[ip + 3] - output[ip + 2]; i++)
	buf[i] = output[ip + 4 + i];
    }
    printf("0x%02X 0x%02X 0x%02X 0x%02X\n",
	   output[ip], output[ip + 1],
	   output[ip + 2], output[ip + 3]);
    r = 4 + i;
    break;
    /* (char, int, int, int, char) */
  case 2:
    w = output[ip + 2];
    x = output[ip + 4] << 8 | output[ip + 3];
    y = output[ip + 6] << 8 | output[ip + 5];
    z = output[ip + 8] << 8 | output[ip + 7];
    printf("0x%02X 0x%02X 0x%02X 0x%04X 0x%04X 0x%04X 0x%02X\n",
	   output[ip], output[ip + 1], w, x, y, z,
	   output[ip + 9]);
    r = 10;
    break;
  }
  return r;
}

int func_17(int ip)
{
  printf("0x%02X 0x%02X\n", output[ip], output[ip + 1]);
  return 2;
}

int func_18(int ip)
{
  printf("0x%02X\n", output[ip]);
  return 1;
}

int func_19(int ip)
{
  int w, x, y, z;

  w = output[ip + 3] << 8 | output[ip + 2];
  x = output[ip + 5] << 8 | output[ip + 4];
  y = output[ip + 7] << 8 | output[ip + 6];
  z = output[ip + 9] << 8 | output[ip + 8];
  switch (output[ip + 1]) {
  case 1:
    copy_sub_to_main(w, x, y, z);
    break;
  case 2:
    fill_rectangle(w, x, y, z, output[ip + 10]);
    break;
  case 3:
    clear_75(w, x, y, z);
    break;
  }
  return 11;
}

int func_1a(int ip)
{
  int r;
  int x;

  r = 0;
  switch (output[ip + 1]) {
    /* (int) */
  case 0:
    x = output[ip + 3] << 8 | output[ip + 2];
    printf("0x%02X 0x%02X 0x%04X\n", output[ip], output[ip + 1], x);
    r = 4;
    break;
    /* (void) */
  case 1: case 3:
    printf("0x%02X 0x%02X\n", output[ip], output[ip + 1]);
    r = 2;
    break;
    /* (char) */
  case 2:
    printf("0x%02X 0x%02X 0x%02X\n",
	   output[ip], output[ip + 1], output[ip + 2]);
    r = 3;
    break;
  }
  return r;
}

int func_1b(int ip)
{
  retn();
  return 1;
}

int func_1c(int ip)
{
  set_palette();
  return 1;
}

int func_1d(int ip)
{
  make_delay(output[ip + 1]);
  return 2;
}

int func_1e(int ip)
{
  int r;
  r = 0;
  switch (output[ip + 1]) {
  case 1:
    input_name();
    r = 2;
    break;
    /* (char) */
  case 6:
    save_hoehoe_dat(output[ip + 2]);
    r = 3;
    break;
    /* (void) */
  case 2: case 3: case 4: case 5:
    printf("0x%02X 0x%02X\n", output[ip], output[ip + 1]);
    r = 2;
    break;
  case 7:
    change_destination_and_esc();
    r = 2;
    break;
  case 8:
    change_destination_and_esc_to_default();
    r = 2;
    break;
  case 9:
    save_load_menu();
    r = 2;
    break;
  }
  return r;
}

int func_1f(int ip)
{
  change_diskette(output[ip + 1]);
  return 2;
}

int func_20(int ip)
{
  switch (output[ip + 1]) {
  case 0:
    enable_system_menu();
    break;
  case 1:
    disable_system_menu();
    break;
  case 2:
    make_check_point();
    break;
  }
  return 2;
}

int func_80(int ip)
{
  refer_str(output[ip + 1]);
  return 2;
}

int func_others(int ip)
{
  int c, d;
  int j;
  int ms;

  for (j = 0; ; j += 2) {
    c = output[ip + j];
    d = output[ip + j + 1];
    if (!isprint(c))
      break;
    ms = jis2euc(d, c);
    putchar(ms >> 8);
    putchar(ms);
  }
  putchar('\n');
  return j;
}

int (*funcs[])(int) = {
  func_00, func_01, func_02, func_03, func_04, func_05, func_06, func_07,
  func_08, func_09, func_0a, func_0b, func_0c, func_0d, func_0e, func_0f,
  func_10, func_11, func_12, func_13, func_14, func_15, func_16, func_17,
  func_18, func_19, func_1a, func_1b, func_1c, func_1d, func_1e, func_1f,
  func_20,
};

void print_list(int bufsize)
{
  int i;
  int c;
  int (*func)(int);

  for (i = 0; i < bufsize;) {
    c = output[i];
    printf("0x%04X: ", (int)i);
    if (c <= 0x20)
      func = funcs[c];
    else if (c == 0x80)
      func = func_80;
    else
      func = func_others;
    i += (*func)(i);
  }
}

void main(int argc, char **argv)
{
  FILE *fp;
  unsigned char c[4];
  int txt_ex_bufsize;

  if (argc != 2)
    exit(1);
  fp = fopen(argv[1], "rb");
  fseek(fp, 4l, SEEK_SET);	/* magic & size */
  fread(c, 4, 1, fp);
  txt_ex_bufsize = c[3] << 24 | c[2] << 16 | c[1] << 8 | c[0];
  output = malloc(txt_ex_bufsize);
  expand_file(fp, output, txt_ex_bufsize);
  fclose(fp);

  print_list(txt_ex_bufsize);

  free(output);
}
