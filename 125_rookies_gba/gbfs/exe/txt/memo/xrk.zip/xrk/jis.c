#include "jis.h"

int msc2jis(int a1)
     /* a1 is reverse ordered SJIS */
{
  int ax;
  char ah, al;
  int carry;

  ax = a1;
  ah = ax & 0xff;
  al = (ax >> 8) & 0xff;
  ah <<= 1;
  ah &= 0xff;
  carry = (al < 0x1f) ? 1 : 0;
  al -= 0x1f;
  al &= 0xff;
  if (carry == 0)
    al += 0xde + ((al < 0x61) ? 1 : 0);
  ax = (ah << 8) | (al & 0xff);
  ax += 0x1fa1;
  ax &= 0x7f7f;
  return ax;
}

int jis2msc(int h, int l)
{
  unsigned int x;
  unsigned char p, q;

  x = (h - 0x21) * 0x5e + (l - 0x21);

  p = x % 0xbc;
  q = x / 0xbc;
  p += 0x40;
  if (p >= 0x7f)
    p++;
  if (q < 0x1f)
    q = q + 0x81;
  else
    q = q - 0x1f + 0xe0;

  p &= 0xff;
  q &= 0xff;

  return (q << 8) | p;
}

int jis2euc(int h, int l)
{
  unsigned char p, q;

  p = l | 0x80;
  q = h | 0x80;

  return (q << 8) | p;
}
