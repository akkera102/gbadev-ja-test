#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include "jis.h"
#include "exp.h"
#include "anim.h"
#include "rookiesstr.h"
#include "rookiesP.h"
#include "scenario.h"
#include "mig.h"
#include "poi.h"

#define CURTAIN_X 72
#define CURTAIN_Y 16
#define CURTAIN_WIDTH 496
#define CURTAIN_HEIGHT 288

/* Widget */

static void Initialize(), Destroy(), Redisplay();
static void die(), leftevent(), rightevent(), upevent(), downevent(), cancel(), confirm(), escape(), speedctl(), motion();

#define offset(field) XtOffsetOf(RookiesRec, rookies.field)
static XtResource resources[] = {
  {XtNup, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(up), XtRCallback, (XtPointer)NULL},
  {XtNdown, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(down), XtRCallback, (XtPointer)NULL},
  {XtNright, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(right), XtRCallback, (XtPointer)NULL},
  {XtNleft, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(left), XtRCallback, (XtPointer)NULL},
  {XtNcancel, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(cancel), XtRCallback, (XtPointer)NULL},
  {XtNconfirm, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(confirm), XtRCallback, (XtPointer)NULL},
  {XtNescape, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(escape), XtRCallback, (XtPointer)NULL},
  {XtNspeedctl, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(speedctl), XtRCallback, (XtPointer)NULL},
  {XtNmotion, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(motion), XtRCallback, (XtPointer)NULL},
  {XtNdie, XtCCallback, XtRCallback, sizeof(XtPointer),
     offset(die), XtRCallback, (XtPointer)NULL},
  {XtNfont, XtCFont, XtRFontStruct, sizeof(XFontStruct *),
     offset(font), XtRString, XtDefaultFont},
};
#undef offset

static XtActionsRec actions[] = {
  {"die", die},
  {"left", leftevent},
  {"right", rightevent},
  {"up", upevent},
  {"down", downevent},
  {"cancel", cancel},
  {"confirm", confirm},
  {"escape", escape},
  {"speedctl", speedctl},
  {"motion", motion},
};

static char translations[] =
"<KeyPress>f	: right()\n"
"<KeyPress>b	: left()\n"
"<KeyPress>p	: up()\n"
"<KeyPress>n	: down()\n"
"<KeyPress>h	: left()\n"
"<KeyPress>j	: down()\n"
"<KeyPress>k	: up()\n"
"<KeyPress>l	: right()\n"
"<KeyPress>Right	: right()\n"
"<KeyPress>Left	: left()\n"
"<KeyPress>Up	: up()\n"
"<KeyPress>Down	: down()\n"
"<KeyPress>KP_Right	: right()\n"
"<KeyPress>KP_Left	: left()\n"
"<KeyPress>KP_Up	: up()\n"
"<KeyPress>KP_Down	: down()\n"
"<KeyPress>space	: cancel()\n"
"<KeyPress>Return	: confirm()\n"
"<KeyPress>KP_Enter	: confirm()\n"
"<KeyPress>KP_Insert	: confirm()\n"
"<KeyPress>Escape	: escape()\n"
"<Btn1Down>	: confirm()\n"
"<Btn2Down>	: speedctl()\n"
"<Btn3Down>	: cancel()\n"
"<KeyPress>s	: speedctl()\n"
"<MotionNotify>	: motion()\n"
"Shift <KeyPress>q	: die()\n"
;

RookiesClassRec rookiesClassRec = {
    { /* core fields */
    /* superclass               */      (WidgetClass) &widgetClassRec,
    /* class_name               */      "Rookies",
    /* widget_size              */      sizeof(RookiesRec),
    /* class_initialize         */      NULL,
    /* class_part_initialize    */      NULL,
    /* class_inited             */      FALSE,
    /* initialize               */      Initialize,
    /* initialize_hook          */      NULL,
    /* realize                  */      XtInheritRealize,
    /* actions                  */      actions,
    /* num_actions              */      XtNumber(actions),
    /* resources                */      resources,
    /* resource_count           */      XtNumber(resources),
    /* xrm_class                */      NULLQUARK,
    /* compress_motion          */      TRUE,
    /* compress_exposure        */      XtExposeGraphicsExpose,
    /* compress_enterleave      */      TRUE,
    /* visible_interest         */      FALSE,
    /* destroy                  */      Destroy,
    /* resize                   */      NULL,
    /* expose                   */      Redisplay,
    /* set_values               */      NULL,
    /* set_values_hook          */      NULL,
    /* set_values_almost        */      NULL,
    /* get_values_hook          */      NULL,
    /* accept_focus             */      NULL,
    /* version                  */      XtVersion,
    /* callback_private         */      NULL,
    /* tm_table                 */      translations,
    /* query_geometry           */      XtInheritQueryGeometry,
    /* display_accelerator      */      XtInheritDisplayAccelerator,
    /* extension                */      NULL
    },
    { /* rookies fields */
    /* ignore                   */      0
    }
};

WidgetClass rookiesWidgetClass = (WidgetClass) &rookiesClassRec;

/* */

static void Initialize(Widget request, Widget new, ArgList args, Cardinal *num_args)
{
  RookiesWidget w = (RookiesWidget)new;
  Display *display = XtDisplay(new);
  int screen = DefaultScreen(display);
  int depth = DefaultDepth(display, screen);

  if (w->core.width < 1) w->core.width = 640;
  if (w->core.height < 1) w->core.height = 400;

  w->rookies.gc = XtAllocateGC(request, depth, 0, NULL, GCForeground | GCGraphicsExposures, 0);
  XSetGraphicsExposures(XtDisplay(w), w->rookies.gc, TRUE);
}

static void Destroy(Widget gw)
{
  RookiesWidget w = (RookiesWidget) gw;

  free(w->rookies.curtain_rect);
  XtReleaseGC(gw, w->rookies.gc);
}

static void Redisplay(Widget gw, XEvent *event, Region region)
{
  RookiesWidget w = (RookiesWidget)gw;
  int i;
  GC gc;
  Display *display = XtDisplay(gw);
  Window window = XtWindow(gw);
  int screen = DefaultScreen(display);
  int x, y, width, height;
  XRectangle rect;
  int current_display;

  if ((event->type == Expose || event->type == GraphicsExpose) && w->core.visible) {
    if (event->type == Expose) {
      rect.x = event->xexpose.x;
      rect.y = event->xexpose.y;
      rect.width = event->xexpose.width;
      rect.height = event->xexpose.height;
    } if (event->type == GraphicsExpose) {
      rect.x = event->xgraphicsexpose.x;
      rect.y = event->xgraphicsexpose.y;
      rect.width = event->xgraphicsexpose.width;
      rect.height = event->xgraphicsexpose.height;
    }
    x = rect.x; y = rect.y;
    width = rect.width; height = rect.height;
    current_display = w->rookies.current_display;
    XCopyArea(display, w->rookies.pixmap[current_display], window,
	      DefaultGC(display, screen),
	      x, y, width, height, x, y);
    if (w->rookies.curtain_moving == True) {
      for (i = 0; i < w->rookies.curtain_rect_num; i++) {
	w->rookies.curtain_rect[i].x = CURTAIN_X;
	w->rookies.curtain_rect[i].y = CURTAIN_Y + i * MAX_CURTAIN;
	w->rookies.curtain_rect[i].width = CURTAIN_WIDTH;
	w->rookies.curtain_rect[i].height = w->rookies.curtain_count;
	if (w->rookies.curtain_rect[i].y + w->rookies.curtain_rect[i].height > CURTAIN_HEIGHT)
	  w->rookies.curtain_rect[i].height = CURTAIN_HEIGHT - w->rookies.curtain_rect[i].y + 1;
	XFillRectangles(display, window, DefaultGC(display, screen),
			w->rookies.curtain_rect, w->rookies.curtain_rect_num);
      }
    } else {
      if (w->rookies.curtain_opened == True) {
	/* ��ϳ����Ƥ��� */
	/* ���⤷�ʤ� */
      } else {
	/* ����Ĥ��Ƥ��� */
	XFillRectangle(display, window, DefaultGC(display, screen),
		       CURTAIN_X, CURTAIN_Y, CURTAIN_WIDTH, CURTAIN_HEIGHT);
      }
    }
    if (w->rookies.texton != False || w->rookies.inmenu != False) {
      int i, j, j1, c, c1;
      XChar2b s2b[TEXTWIDTH];

      for (i = 0; i < TEXTHEIGHT; i++) {
	j = 0;
	for (;;) {
	  while (j < TEXTWIDTH &&
		 !w->rookies.text[j][i][0] && !w->rookies.text[j][i][1])
	    j++;
	  if (j == TEXTWIDTH) break;

	  c = w->rookies.text_attr[j][i];
	  j1 = j;
	  c1 = c;
	  while (c1 == c && j < TEXTWIDTH &&
		 (w->rookies.text[j][i][0] || w->rookies.text[j][i][1])) {
	    s2b[j].byte1 = w->rookies.text[j][i][0];
	    s2b[j].byte2 = w->rookies.text[j][i][1];
	    c = w->rookies.text_attr[++j][i];
	  }
	  gc = w->rookies.textgc[c1];
	  XDrawString16(display, window, gc,
			j1 * 16, i * 16 + w->rookies.font->ascent,
			s2b + j1, j - j1);
	}
      }
    }
  }
  XStoreColors(display, w->rookies.colormap, w->rookies.color, NCOLORS);
}

/* */

int RookiesGetWidth(Widget w)
{
  return w->core.width;
}

int RookiesGetHeight(Widget w)
{
  return w->core.height;
}

XFontStruct *RookiesGetFontStruct(Widget w)
{
  RookiesWidget gw = (RookiesWidget)w;

  return gw->rookies.font;
}

void RookiesSetPixmap(Widget w, Pixmap pixmap, int n)
{
  RookiesWidget gw = (RookiesWidget)w;

  gw->rookies.pixmap[n] = pixmap;
}

Pixmap RookiesGetPixmap(Widget w, int n)
{
  RookiesWidget gw = (RookiesWidget)w;

  return gw->rookies.pixmap[n];
}

void RookiesClearPixmap(Widget w, int n, unsigned long color)
{
  RookiesWidget gw = (RookiesWidget)w;

  XSetForeground(XtDisplay(w), gw->rookies.gc, color);
  XFillRectangle(XtDisplay(w), gw->rookies.pixmap[n], gw->rookies.gc, 0, 0, w->core.width, w->core.height);
}

/* Widget End */

/* %%%%%%%%%%%%%%%%% */

char *textcolnames[NTXTCOLS] = {
  "black",
  "blue",
  "red",
  "magenta",
  "green",
  "cyan",
  "yellow",
  "white",
};
extern Colormap colormap;

unsigned char *scenario_buf;
char *scenario_filename;

#define NVAL 256
#define CALLSTACKLEN 256
#ifndef PATH_MAX
#define PATHLEN 1024
#else
#define PATHLEN PATH_MAX
#endif

typedef struct _context_t {
  int variable[NVAL];
  char filename[PATHLEN];
  int ip;
  int stack[CALLSTACKLEN];
  int stackptr;
  int show_text;
  int text_color;
  int system_menu_enabled;
  int escape_normal;
  int graphic_origin_x, graphic_origin_y;
  int dialog_box_x0, dialog_box_y0, dialog_box_x1, dialog_box_y1;
  int cursor_x, cursor_y;
  int timeout_confirm, show_prompt;
  Boolean cursor_visible;
} context_t;

context_t current, saved, tmp;

typedef void (*input_hook_t)(Widget, int);

input_hook_t input_hook = NULL;
struct timeval input_timeout;

unsigned char *idx_buf, *pix_buf;

typedef struct _mouse_loc_t {
  int x, y;
} mouse_loc_t;

mouse_loc_t mouse_loc;

typedef struct _menu_status_t {
  char **menu_items;
  int val;
  int item_num;
  int start, end;
  int current_selection;
} menu_status_t;

menu_status_t menu_status;



#define CURSOR_BLINK 100
#define TIMEOUT_CONFIRM 1000
#define FADE_TICKS 10
#define ANIM_TICKS 10
#define CURTAIN_TICKS (1000 / MAX_CURTAIN)

#define HOEHOEDAT "hoehoe.dat"

#define MAIN_SCREEN(w) ((w)->rookies.current_display)
#define SUB_SCREEN(w) (((w)->rookies.current_display == 1) ? 0 : 1)

char *embedded_string[] = {
  "�ߤ��Ҥ�",
  "�ߤ��Ҥ�",
  "�ٹ路�Ƥ����ܤΰ������硼�ȥ��åȤΥ��磻�����ҹ���",
  "�ٹ路�Ƥ����ܤ��������ʤⰭ�����硼�ȥ��åȤν��ҹ���",
  "�ٹ路�Ƥ������ʤ��������硼�ȥ��åȤν��ҹ���",
  "���վ�",
  "�շ�",
  "�ӣ��ãˣ�",
  "������",
  "ͭ�Ͻ人",
  "Ȩ¼������",
  "������̼",
  "����",
  "�Ӵ�",
  "����",
  "�Ҥ���",
  "Τ��",
  "����",
  "����",
  "˾��",
  "ͳ����",
  "��Ĺ",
  "����",
  "����",
  "����",
  "�ܥ�",
  "�ۻ�",
};

char *menu_spcs="������������������������������������������������������������";
char *menu_save="���������������������������������֡�������������������������";
char *menu_load="���������������������������������ɡ�������������������������";
char *menu_quit="�������������������������������λ���롡������������������";
char *menu_back="�������������������������������Ƴ����롡������������������";
char *menu_chk="�����������ģϣӤ����ޤ������ˤ�������Ǥ�����������������";
char *menu_cfm="��������������������������������λ��������������������������";
char *menu_can="�����������������������������ͤ�ľ��������������������������";
char *menu_prev="���������������������������Υڡ����ء�����������������������";
char *menu_next="���������������������������Υڡ����ء�����������������������";
/*              012345678901234567890123456789012345678901234567890123456789 */
char *menu_e = "�����������֥ǡ������������������������������������ʬ����";
char *menu_n = "�����������֥ǡ������������������ޤ������֤���Ƥ��ޤ��󡡡�";
char *save_file[4] = {
  "save0.dat",
  "save1.dat",
  "save2.dat",
  "save3.dat",
};

Boolean workproc(XtPointer client_data)
{
  int result;

  result = scenario((RookiesWidget)client_data);
  if (result == SLEEP)
    return True;
  return False;
}

void register_work_proc(Widget w)
{
  RookiesWidget rw = (RookiesWidget)w;
  Display *display = XtDisplay(w);
  XtAppContext xt = XtDisplayToApplicationContext(display);
  rw->rookies.workprocid = XtAppAddWorkProc(xt, workproc, (XtPointer)rw);
}

void timeout(XtPointer client_data, XtIntervalId *id)
{
  timeout_handler((Widget)client_data);
}

void register_timeout(Widget w, unsigned long interval)
{
  RookiesWidget rw = (RookiesWidget)w;
  Display *display = XtDisplay(rw);
  XtAppContext xt = XtDisplayToApplicationContext(display);
  rw->rookies.timer = XtAppAddTimeOut(xt, interval, timeout, rw);
}

void unregister_timeout(Widget w)
{
  RookiesWidget rw = (RookiesWidget)w;
  XtRemoveTimeOut(rw->rookies.timer);
}

void send_redraw_event(RookiesWidget rw, int x, int y, int width, int height)
{
  XEvent event;

  event.xexpose.type = Expose;
  event.xexpose.window = XtWindow(rw);
  event.xexpose.x = x;
  event.xexpose.y = y;
  event.xexpose.width = width;
  event.xexpose.height = height;
  event.xexpose.count = 0;
  XSendEvent(XtDisplay(rw), XtWindow(rw), False, 0, &event);
}

void query_mouse_pointer(Widget w)
{
  Window root, child;
  int x, y, wx, wy;
  unsigned int mask;
  Bool result;

  result = XQueryPointer(XtDisplay(w), XtWindow(w),
			 &root, &child, &x, &y, &wx, &wy, &mask);

  mouse_loc.x = wx;
  mouse_loc.y = wy;
}

char *convert_to_8_3(char *filename)
{
  char *p, *q, *r, *s;

  p = malloc(strlen(filename) + 1 + 2);	/* 1 for '\0' and 2 for "./" */
  strcpy(p, ".");
  r = filename;
  while ((q = strtok(r, "/")) != NULL) {
    r = NULL;
    if ((s = index(q, '.')) != NULL) {
      strcat(p, "/");
      strncat(p, q, (s - q <= 8) ? s - q : 8);
      strcat(p, ".");
      strncat(p, s + 1,
	      (strlen(q) - (s + 1 - q) <= 3) ? strlen(q) - (s + 1 - q) : 3);
    } else {
      strcat(p, "/");
      strcat(p, q);
    }
  }
  return p;
}

char *canonicalize_filename(char *filename)
{
  char *p, *q, *r;
  int i, len;

  len = strlen(filename);
  p = q = (char *)malloc(len + 1);
  for (i = 0; i < len; i++) {
    if (filename[i] == '\\') {
      if (filename[i + 1] == '\\') {
	*q++ = '/';
	i++;
      } else {
	*q++ = '/';
      }
    } else {
      *q++ = tolower(filename[i]);
    }
  }
  *q = '\0';
  r = convert_to_8_3(p);
  free(p);
  return r;
}

void free_scenario(unsigned char *buf)
{
  if (buf != NULL)
    free(buf);
}

unsigned char *expand_scenario_file(char *filename)
{
  FILE *fp;
  int bufsize;
  unsigned char c[4];
  unsigned char *buf;

  if ((fp = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "scenario file \"%s\" not found\n", filename);
    exit(1);
  }
  fseek(fp, 4l, SEEK_SET);	/* magic & size */
  fread(c, 4, 1, fp);
  bufsize = c[3] << 24 | c[2] << 16 | c[1] << 8 | c[0];
  buf = malloc(bufsize);
  expand_file(fp, buf, bufsize);
  fclose(fp);
  return buf;
}

void free_pix(unsigned char *buf)
{
  if (buf != NULL)
    free(buf);
}

unsigned char *expand_pix_file(char *filename)
{
  FILE *fp;
  int bufsize;
  unsigned char c[4];
  unsigned char *buf;

  if ((fp = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "scenario file \"%s\" not found\n", filename);
    exit(1);
  }
  fseek(fp, 4l, SEEK_SET);	/* magic & size */
  fread(c, 4, 1, fp);
  bufsize = c[3] << 24 | c[2] << 16 | c[1] << 8 | c[0];
  buf = malloc(bufsize);
  expand_file(fp, buf, bufsize);
  fclose(fp);
  return buf;
}

void free_idx(unsigned char *buf)
{
  if (buf != NULL)
    free(buf);
}

unsigned char *expand_idx_file(char *filename)
{
  FILE *fp;
  int bufsize;
  unsigned char c[4];
  unsigned char *buf;

  if ((fp = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "idx file \"%s\" not found\n", filename);
    exit(1);
  }
  fseek(fp, 4l, SEEK_SET);	/* magic & size */
  fread(c, 4, 1, fp);
  bufsize = c[3] << 24 | c[2] << 16 | c[1] << 8 | c[0];
  buf = malloc(bufsize);
  expand_file(fp, buf, bufsize);
  fclose(fp);
  return buf;
}

#define FACTOR 0x1111
void change_palette(RookiesWidget rw, unsigned char *palette)
{
  int i;
  XColor *color;
  Display *display;
  int colnum = 16;

  display = XtDisplay(rw);
  for (i = 0; i < colnum; i++) {
    color = &rw->rookies.targetcolor[i];
    color->red = palette[3 * i + 1] * FACTOR;
    color->green = palette[3 * i + 0] * FACTOR;
    color->blue = palette[3 * i + 2] * FACTOR;
    color->flags = DoRed|DoGreen|DoBlue;
  }
}

void draw_mig(RookiesWidget rw, unsigned char col, char *filename)
{
  cg_t cg;
  XImage *ximage;
  Display *display;
  GC gc;
  int x, y, width, height;
  int i, j;

  display = XtDisplay(rw);
  gc = rw->rookies.gc;
  /* ����Ÿ�������ؤ��ؤ������Ƥۤ��ۤ����� */
  cg = expand_picture((Widget)rw, filename);
  x = current.graphic_origin_x;
  y = current.graphic_origin_y;
  width = cg->width;
  height = cg->height;
  /* �Ť͹�碌�ν����򤹤� */
  if (col != 0xff) {		/* �Ť͹�碌ɬ�� */
    ximage = XGetImage(display, rw->rookies.pixmap[SUB_SCREEN(rw)],
		       x, y, width, height, 0xff, ZPixmap);
    for (i = 0; i < height; i++) {
      for (j = 0; j < width; j++) {
	unsigned long ppp;
	ppp = XGetPixel(cg->ximage, j, i);
	if (col == ppp) {
	  XPutPixel(cg->ximage, j, i, XGetPixel(ximage, j, i));
	} else {
	  XPutPixel(cg->ximage, j, i, rw->rookies.color[ppp].pixel);
	}
      }
    }
    XDestroyImage(ximage);
  } else {
    for (i = 0; i < height; i++)
      for (j = 0; j < width; j++) {
	unsigned long ppp;
	ppp = XGetPixel(cg->ximage, j, i);
	XPutPixel(cg->ximage, j, i, rw->rookies.color[ppp].pixel);
      }
    change_palette(rw, cg->palette);
  }
  /* SUB �β��̤˽񤭹��� */
  XPutImage(display, rw->rookies.pixmap[SUB_SCREEN(rw)], gc,
	    cg->ximage, 0, 0, x, y, width, height);
  /* ����ؤ��ؤ��ΤƤ� */
  free_picture(cg);
}

void exec_file(char *p)
{
  /* ������ filename ����ꤷ��Ŭ���˽�������� */
  char *filename;
  
  free_scenario(scenario_buf);
  scenario_buf = NULL;
  if (scenario_filename != NULL)
    free(scenario_filename);
  filename = canonicalize_filename(p);
  scenario_filename = strdup(filename);
  strcpy(current.filename, scenario_filename);
  free(filename);
}

void display_letter(RookiesWidget rw, char *c)
{
  int x, y;

  x = current.cursor_x;
  y = current.cursor_y;
  rw->rookies.text[x][y][0] = *c & 0x7f;
  rw->rookies.text[x][y][1] = *(c + 1) & 0x7f;
  rw->rookies.text_attr[x][y] = current.text_color;
  current.cursor_x = x + 1;
  if (current.cursor_x > current.dialog_box_x1) {
    current.cursor_x = current.dialog_box_x0;
    current.cursor_y++;
  }
}

void clear_dialog_box(RookiesWidget rw)
{
  int i, j;
  int x, y, width, height;
  
  for (i = 0; i < TEXTHEIGHT; i++) {
    for (j = 0; j < TEXTWIDTH; j++) {
      rw->rookies.text[j][i][0] = '\0';
      rw->rookies.text[j][i][1] = '\0';
      rw->rookies.text_attr[j][i] = 0;
    }
  }
  current.cursor_x = current.dialog_box_x0;
  current.cursor_y = current.dialog_box_y0;
  x = current.dialog_box_x0 * 16;
  y = current.dialog_box_y0 * 16;
  width = (current.dialog_box_x1 - current.dialog_box_x0 + 1) * 16;
  height = (current.dialog_box_y1 - current.dialog_box_y0 + 1) * 16;
  send_redraw_event(rw, x, y, width, height);
}

void display_menu_items(RookiesWidget rw)
{
  int i, j;
  int x, y;

  clear_dialog_box(rw);
  rw->rookies.inmenu = True;
  x = current.dialog_box_x0;
  y = current.dialog_box_y0;
  for (i = 0; i < menu_status.item_num; i++) {
    for (j = 0; menu_status.menu_items[i][j] != '\0'; j++) {
      rw->rookies.text[x + j / 2][y + i][j % 2] = menu_status.menu_items[i][j] & 0x7f;
      if (i != menu_status.current_selection)
	rw->rookies.text_attr[x + j / 2][y + i] = 0; /* black */
      else
	rw->rookies.text_attr[x + j / 2][y + i] = 2; /* red */
    }
  }
  send_redraw_event(rw, 0, 0, 0, 0);
}

void menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    current.variable[menu_status.val] = menu_status.current_selection;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
  /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
  /* ���̤�ä��Τ�˺�줺�� */
    rw->rookies.inmenu = False;
    clear_dialog_box(rw);
    input_hook = NULL;
    register_work_proc(w);
  }
}

void menu(RookiesWidget rw, char *items[])
{
  display_menu_items(rw);
  input_hook = menu_ip;
}

void copy_sub_to_main(RookiesWidget rw, int x1, int y1, int x2, int y2)
{
  Display *display;
  GC gc;
  int x, y;
  int width, height;

  display = XtDisplay(rw);
  gc = rw->rookies.gc;
  x = x1 * 8; y = y1;
  width = (x2 - x1 + 1) * 8;
  height = y2 - y1 + 1;
  XCopyArea(display, rw->rookies.pixmap[SUB_SCREEN(rw)],
	    rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	    x, y, width, height, x, y);
  send_redraw_event(rw, x, y, width, height);
}

void fill_rectangle(RookiesWidget rw, int x1, int y1, int x2, int y2,
		    unsigned char col)
{
  Display *display;
  GC gc;
  int x, y;
  int width, height;
  XGCValues values;
  unsigned long valuemask;

  display = XtDisplay(rw);
  valuemask = GCForeground;
  values.foreground = rw->rookies.color[col].pixel;
  gc = XCreateGC(display, rw->rookies.pixmap[MAIN_SCREEN(rw)],
		 valuemask, &values);
  x = x1 * 8; y = y1;
  width = (x2 - x1 + 1) * 8;
  height = y2 - y1 + 1;
  XFillRectangle(display, rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
		 x, y, width, height);
  XFreeGC(display, gc);
}

void clear_75(RookiesWidget rw, int x1, int y1, int x2, int y2)
{
  Display *display;
  GC gc;
  XImage *ximage;
  int x, y;
  int width, height;
  int i, j;

  display = XtDisplay(rw);
  gc = rw->rookies.gc;
  x = x1 * 8; y = y1;
  width = (x2 - x1 + 1) * 8;
  height = y2 - y1 + 1;
  ximage = XGetImage(display, rw->rookies.pixmap[MAIN_SCREEN(rw)],
		     x, y, width, height, 0xff, ZPixmap);
  for (i = 0; i < height; i += 2)
    for (j = 0; j < width; j++)
      if ((i % 2 == 1) && (j % 2 == 1))
	ximage->data[i * height + j] = rw->rookies.color[0].pixel;
  XPutImage(display, rw->rookies.pixmap[MAIN_SCREEN(rw)], gc, ximage,
	    0, 0, x, y, width, height);
  XDestroyImage(ximage);
}

void refer_str(RookiesWidget rw, int n)
{
  unsigned char *c;
  char left[] = "��";
  char right[] = "��";

  if (n == 0) {
    c = embedded_string[n];
    while (*c != '\0') {
      display_letter(rw, c);
      c += 2;
    }
  } else {
    c = left;
    while (*c != '\0') {
      display_letter(rw, c);
      c += 2;
    }
    c = embedded_string[n];
    while (*c != '\0') {
      display_letter(rw, c);
      c += 2;
    }
    c = right;
    while (*c != '\0') {
      display_letter(rw, c);
      c += 2;
    }
    current.cursor_x = current.dialog_box_x0;
    current.cursor_y++;
  }
  send_redraw_event(rw, 0, 0, 0, 0);
}

void make_delay_ip(Widget w, int last_key)
{
  if (last_key != MOTION) {
    unregister_timeout(w);
    register_work_proc(w);
  }
}

void make_delay(RookiesWidget rw, int x)
{
  register_timeout((Widget)rw, x * 20);
  input_hook = make_delay_ip;
}

void set_palette(RookiesWidget rw)
{
  int i;
  for (i = 0; i < NCOLORS; i++) {
    rw->rookies.color[i].red = rw->rookies.targetcolor[i].red;
    rw->rookies.color[i].blue = rw->rookies.targetcolor[i].blue;
    rw->rookies.color[i].green = rw->rookies.targetcolor[i].green;
  }
}

void save_load_menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;
  FILE *fp;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    confirmed = True;
    /* ���⤻��ȴ���� */
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
    /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
    /* ���̤�ä��Τ�˺�줺�� */
    rw->rookies.inmenu = False;
    clear_dialog_box(rw);
    if (last_key == CONFIRM &&
	((fp = fopen(save_file[menu_status.current_selection], "rb")) != NULL)) {
      clear_dialog_box(rw);
      fread(&current, sizeof(current), 1, fp);
      fclose(fp);
      free_scenario(scenario_buf);
      scenario_buf = NULL;
      if (scenario_filename != NULL)
	free(scenario_filename);
      scenario_filename = strdup(current.filename);
    } else {
      /* ��˥塼��ɽ�����֤��᤹ */
      current.dialog_box_x0 = tmp.dialog_box_x0;
      current.dialog_box_y0 = tmp.dialog_box_y0;
      current.dialog_box_x1 = tmp.dialog_box_x1;
      current.dialog_box_y1 = tmp.dialog_box_y1;
    }
    input_hook = NULL;
    register_work_proc(w);
    send_redraw_event(rw, 0, 0, 640, 400);
  }
}

void build_save_load_menu(RookiesWidget rw)
{
  int i;
  FILE *fp[4];
  struct stat sb[4];
  time_t mtime[4];
  struct tm mtime_tm[4];

  /* �����֥ǡ����ϻͤĤޤǡ�����ʾ���б��ʤ� */
  for (i = 0; i < 4; i++) {
    fp[i] = fopen(save_file[i], "rb");
    if (fp[i] != NULL) {
      fstat(fileno(fp[i]), &sb[i]);
      mtime[i] = sb[i].st_mtime;
      memcpy(&mtime_tm[i], localtime(&mtime[i]), sizeof(struct tm));
    }
  }
  /* �����Ĥ���˥塼�ν����δ֤˸ƤФ�뤳�Ȥ�̵���Ϥ��� */
  /* �Ȥ���������˥塼���ФƤ���Ȥ����ǳ�ꤳ�����Ϥ��ʤ��Ϥ� */
  menu_status.item_num = 4;
  menu_status.start = 0;
  menu_status.end = 3;
  menu_status.val = NVAL;
  menu_status.menu_items = (char **)calloc(sizeof(char *),
					   menu_status.item_num);
  menu_status.current_selection = 0;
  for (i = 0; i < 4; i++) {
    if (fp[i] == NULL) {
      menu_status.menu_items[i] = strdup(menu_n);
      menu_status.menu_items[i][19] = '0' + i;
    } else {
      menu_status.menu_items[i] = strdup(menu_e);
      menu_status.menu_items[i][19] = '0' + i;
      menu_status.menu_items[i][31] = '0' + (mtime_tm[i].tm_mon + 1) / 10;
      menu_status.menu_items[i][33] = '0' + (mtime_tm[i].tm_mon + 1) % 10;
      menu_status.menu_items[i][37] = '0' + mtime_tm[i].tm_mday / 10;
      menu_status.menu_items[i][39] = '0' + mtime_tm[i].tm_mday % 10;
      menu_status.menu_items[i][45] = '0' + mtime_tm[i].tm_hour / 10;
      menu_status.menu_items[i][47] = '0' + mtime_tm[i].tm_hour % 10;
      menu_status.menu_items[i][51] = '0' + mtime_tm[i].tm_min / 10;
      menu_status.menu_items[i][53] = '0' + mtime_tm[i].tm_min % 10;
    }
  }
  for (i = 0; i < 4; i++) {
    if (fp[i] != NULL) {
      fclose(fp[i]);
    }
  }
  tmp.dialog_box_x0 = current.dialog_box_x0;
  tmp.dialog_box_y0 = current.dialog_box_y0;
  tmp.dialog_box_x1 = current.dialog_box_x1;
  tmp.dialog_box_y1 = current.dialog_box_y1;
  current.dialog_box_x0 = 5;
  current.dialog_box_y0 = 20;
  current.dialog_box_x1 = 34;
  current.dialog_box_y1 = 23;
}

void save_load_menu(RookiesWidget rw)
{
  build_save_load_menu(rw);
  display_menu_items(rw);
  input_hook = save_load_menu_ip;
}

void free_ani_data(RookiesWidget rw)
{
  free_pix(pix_buf);
  free_idx(idx_buf);
  pix_buf = NULL;
  idx_buf = NULL;
  free_animation((Widget)rw);
}

void cursor_blink(RookiesWidget rw)
{
  int x, y, gx, gy, width, height;
  char cursor[] = "��";

  x = current.dialog_box_x1;
  y = current.dialog_box_y1;
  gx = x * 16;
  gy = y * 16;
  width = height = 16;
  if (current.cursor_visible == True) {
    current.cursor_visible = False;
    rw->rookies.text[x][y][0] = cursor[0] & 0x7f;
    rw->rookies.text[x][y][1] = cursor[1] & 0x7f;
    rw->rookies.text_attr[x][y] = 2; /* red */
  } else {
    current.cursor_visible = True;
    rw->rookies.text[x][y][0] = 0;
    rw->rookies.text[x][y][1] = 0;
    rw->rookies.text_attr[x][y] = 0; /* black */
  }
  send_redraw_event(rw, gx, gy, width, height);
}

void build_system_menu(RookiesWidget rw)
{
  menu_status.item_num = 4;
  menu_status.start = 0;
  menu_status.end = 3;
  menu_status.val = NVAL;
  menu_status.menu_items = (char **)calloc(sizeof(char *),
					   menu_status.item_num);
  menu_status.current_selection = 0;
  menu_status.menu_items[0] = strdup(menu_save);
  menu_status.menu_items[1] = strdup(menu_load);
  menu_status.menu_items[2] = strdup(menu_quit);
  menu_status.menu_items[3] = strdup(menu_back);
  tmp.dialog_box_x0 = current.dialog_box_x0;
  tmp.dialog_box_y0 = current.dialog_box_y0;
  tmp.dialog_box_x1 = current.dialog_box_x1;
  tmp.dialog_box_y1 = current.dialog_box_y1;
  current.dialog_box_x0 = 5;
  current.dialog_box_y0 = 20;
  current.dialog_box_x1 = 34;
  current.dialog_box_y1 = 23;
}

void build_quit_game_menu(RookiesWidget rw)
{
  menu_status.item_num = 4;
  menu_status.start = 1;
  menu_status.end = 2;
  menu_status.val = NVAL;
  menu_status.menu_items = (char **)calloc(sizeof(char *),
					   menu_status.item_num);
  menu_status.current_selection = 1;
  menu_status.menu_items[0] = strdup(menu_chk);
  menu_status.menu_items[1] = strdup(menu_cfm);
  menu_status.menu_items[2] = strdup(menu_can);
  menu_status.menu_items[3] = strdup(menu_spcs);
  tmp.dialog_box_x0 = current.dialog_box_x0;
  tmp.dialog_box_y0 = current.dialog_box_y0;
  tmp.dialog_box_x1 = current.dialog_box_x1;
  tmp.dialog_box_y1 = current.dialog_box_y1;
  current.dialog_box_x0 = 5;
  current.dialog_box_y0 = 20;
  current.dialog_box_x1 = 34;
  current.dialog_box_y1 = 23;
}

void newline_ip(Widget, int);

void save_menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    confirmed = True;
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
    /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
    /* ���̤��᤹�Τ�˺�줺�� */
    rw->rookies.inmenu = False;
    memcpy(rw->rookies.text, rw->rookies.saved_text,
	   sizeof(rw->rookies.text));
    memcpy(rw->rookies.text_attr, rw->rookies.saved_text_attr,
	   sizeof(rw->rookies.text_attr));
    if (last_key == CONFIRM) {
      FILE *fp;
      fp = fopen(save_file[menu_status.current_selection], "wb");
      fwrite(&saved, sizeof(saved), 1, fp);
      fclose(fp);
    } else {
      /* ��˥塼��ɽ�����֤��᤹ */
      current.dialog_box_x0 = tmp.dialog_box_x0;
      current.dialog_box_y0 = tmp.dialog_box_y0;
      current.dialog_box_x1 = tmp.dialog_box_x1;
      current.dialog_box_y1 = tmp.dialog_box_y1;
    }
    if (current.show_prompt == True)
      register_timeout(w, CURSOR_BLINK);
    input_hook = newline_ip;
    send_redraw_event(rw, 0, 0, 640, 400);
  }
}

void save_menu(RookiesWidget rw)
{
  build_save_load_menu(rw);
  display_menu_items(rw);
  input_hook = save_menu_ip;
}

void load_menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;
  FILE *fp;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    confirmed = True;
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
    /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
    /* ���̤��᤹�Τ�˺�줺�� */
    rw->rookies.inmenu = False;
    if (last_key == CONFIRM &&
	((fp = fopen(save_file[menu_status.current_selection], "rb")) != NULL)) {
      clear_dialog_box(rw);
      fread(&current, sizeof(current), 1, fp);
      fclose(fp);
      free_scenario(scenario_buf);
      scenario_buf = NULL;
      if (scenario_filename != NULL)
	free(scenario_filename);
      scenario_filename = strdup(current.filename);
      input_hook = NULL;
      register_work_proc(w);
    } else {
      /* ��˥塼��ɽ�����֤��᤹ */
      current.dialog_box_x0 = tmp.dialog_box_x0;
      current.dialog_box_y0 = tmp.dialog_box_y0;
      current.dialog_box_x1 = tmp.dialog_box_x1;
      current.dialog_box_y1 = tmp.dialog_box_y1;
      memcpy(rw->rookies.text, rw->rookies.saved_text,
	     sizeof(rw->rookies.text));
      memcpy(rw->rookies.text_attr, rw->rookies.saved_text_attr,
	     sizeof(rw->rookies.text_attr));
      if (current.show_prompt == True)
	register_timeout(w, CURSOR_BLINK);
      input_hook = newline_ip;
    }
    send_redraw_event(rw, 0, 0, 640, 400);
  }
}

void load_menu(RookiesWidget rw)
{
  build_save_load_menu(rw);
  display_menu_items(rw);
  input_hook = load_menu_ip;
}

void quit_game_menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    confirmed = True;
    menu_status.current_selection = 2; /* ������Ƴ��Τդ�򤹤� */
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
  /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
    /* ���̤��᤹�Τ�˺�줺�� */
    switch (menu_status.current_selection) {
    case 1:			/* ��λ */
      exit(0);
      break;
    case 2:			/* ������Ƴ� */
      rw->rookies.inmenu = False;
      memcpy(rw->rookies.text, rw->rookies.saved_text,
	     sizeof(rw->rookies.text));
      memcpy(rw->rookies.text_attr, rw->rookies.saved_text_attr,
	     sizeof(rw->rookies.text_attr));
      if (current.show_prompt == True)
	register_timeout(w, CURSOR_BLINK);
      input_hook = newline_ip;
      send_redraw_event(rw, 0, 0, 640, 400);
      break;
    }
  }
}

void quit_game_menu(RookiesWidget rw)
{
  build_quit_game_menu(rw);
  display_menu_items(rw);
  input_hook = quit_game_menu_ip;
}

void system_menu_ip(Widget w, int last_key)
{
  int i;
  Boolean confirmed;
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  /* ���Ϥν��� */
  confirmed = False;
  switch (last_key) {
  case EMPTY:
    break;
  case UP:
    if (menu_status.current_selection > menu_status.start) {
      menu_status.current_selection--;
      display_menu_items(rw);
    }
    break;
  case DOWN:
    if (menu_status.current_selection < menu_status.end) {
      menu_status.current_selection++;
      display_menu_items(rw);
    }
    break;
  case LEFT:
    break;
  case RIGHT:
    break;
  case CONFIRM:
    confirmed = True;
    break;
  case CANCEL:
    break;
  case ESCAPE:
    confirmed = True;
    menu_status.current_selection = 3; /* ������Ƴ��Τդ�򤹤� */
    break;
  case MOTION:
    break;
  }
  if (confirmed == True) {
  /* �Ǹ�ϥ�˥塼�ǳ��ݤ����ǡ����β��� */
    for (i = 0; i < menu_status.item_num; i++)
      free(menu_status.menu_items[i]);
    free(menu_status.menu_items);
    /* ���̤��᤹�Τ�˺�줺�� */
    switch (menu_status.current_selection) {
    case 0:			/* ������ */
      save_menu(rw);
      break;
    case 1:			/* ������ */
      load_menu(rw);
      break;
    case 2:			/* �����ཪλ */
      quit_game_menu(rw);
      break;
    case 3:			/* ������Ƴ� */
      rw->rookies.inmenu = False;
      memcpy(rw->rookies.text, rw->rookies.saved_text,
	     sizeof(rw->rookies.text));
      memcpy(rw->rookies.text_attr, rw->rookies.saved_text_attr,
	     sizeof(rw->rookies.text_attr));
      if (current.show_prompt == True)
	register_timeout(w, CURSOR_BLINK);
      input_hook = newline_ip;
      send_redraw_event(rw, 0, 0, 640, 400);
      break;
    }
  }
}

void system_menu(RookiesWidget rw)
{
  build_system_menu(rw);
  display_menu_items(rw);
  input_hook = system_menu_ip;
}

void newline_ip(Widget w, int last_key)
{
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  if (rw->rookies.display_flipped == True) {
    if (last_key != MOTION && last_key != EMPTY) {
      if (rw->rookies.current_display == 0)
	rw->rookies.current_display = 1;
      else
	rw->rookies.current_display = 0;
      rw->rookies.display_flipped = False;
      rw->rookies.texton = current.show_text = True;
      if (current.show_prompt == True)
	register_timeout(w, CURSOR_BLINK);
      send_redraw_event(rw, 0, 0, 640, 400);
    }
  } else {
    if (current.timeout_confirm == True) {
      if (last_key == EMPTY) {
	clear_dialog_box((RookiesWidget)w);
	input_hook = NULL;
	register_work_proc(w);
	unregister_timeout(w);
      }
    } else if (last_key == CONFIRM || last_key == CANCEL) {
      clear_dialog_box((RookiesWidget)w);
      input_hook = NULL;
      register_work_proc(w);
      unregister_timeout(w);
    } else if (last_key == ESCAPE) {
      if (current.escape_normal == True) {
	if (current.system_menu_enabled == True) {
	  /* system menu */
	  /* �����ǲ��̤���¸����ɬ�פ���� */
	  memcpy(rw->rookies.saved_text, rw->rookies.text,
		 sizeof(rw->rookies.text));
	  memcpy(rw->rookies.saved_text_attr, rw->rookies.text_attr,
		 sizeof(rw->rookies.text_attr));
	  unregister_timeout(w);
	  system_menu(rw);
	}
      } else {
	if (rw->rookies.current_display == 0)
	  rw->rookies.current_display = 1;
	else
	  rw->rookies.current_display = 0;
	rw->rookies.display_flipped = True;
	rw->rookies.texton = current.show_text = False;
	send_redraw_event(rw, 0, 0, 640, 400);
      }
    } else if (last_key == EMPTY) {
      if (current.show_prompt == True) {
	register_timeout(w, CURSOR_BLINK);
	cursor_blink(rw);
      }
    }
  }
}

void newline(RookiesWidget rw)
{
  current.cursor_visible = True;
  if (current.timeout_confirm == True) {
    register_timeout((Widget)rw, TIMEOUT_CONFIRM);
  } else {
    if (current.show_prompt == True)
      register_timeout((Widget)rw, CURSOR_BLINK);
  }
  input_hook = newline_ip;
}

void wait_for_key_ip(Widget rw, int last_key)
{
  if (last_key != EMPTY && last_key != MOTION) {
    input_hook = NULL;
    register_work_proc(rw);
  }
}

void wait_for_key(void)
{
  input_hook = wait_for_key_ip;
}

void fade_ip(Widget w, int last_key)
{
  RookiesWidget rw;
  int i;

  rw = (RookiesWidget)w;
  if (last_key == EMPTY) {
    rw->rookies.count += rw->rookies.speed;
    if (rw->rookies.count >= 100) { /* fade-in ��λ */
      for (i = 0; i < NCOLORS; i++) {
	rw->rookies.color[i].red = rw->rookies.fadeendcolor[i].red;
	rw->rookies.color[i].blue = rw->rookies.fadeendcolor[i].blue;
	rw->rookies.color[i].green = rw->rookies.fadeendcolor[i].green;
      }
      input_hook = NULL;
      register_work_proc(w);
    } else {			/* fade-in ���� */
      for (i = 0; i < NCOLORS; i++) {
	rw->rookies.color[i].red = rw->rookies.fadestartcolor[i].red + (rw->rookies.fadeendcolor[i].red - rw->rookies.fadestartcolor[i].red) * rw->rookies.count / 100;
	rw->rookies.color[i].blue = rw->rookies.fadestartcolor[i].blue + (rw->rookies.fadeendcolor[i].blue - rw->rookies.fadestartcolor[i].blue) * rw->rookies.count / 100;
	rw->rookies.color[i].green = rw->rookies.fadestartcolor[i].green + (rw->rookies.fadeendcolor[i].green - rw->rookies.fadestartcolor[i].green) * rw->rookies.count / 100;
      }
      register_timeout(w, FADE_TICKS);
    }
    send_redraw_event(rw, 0, 0, 0, 0);
  }
}

void fade_in_black(RookiesWidget rw, int x)
{
  int i;

  rw->rookies.count = 0;
  rw->rookies.speed = x;
  for (i = 0; i < NCOLORS; i++) {
    rw->rookies.fadestartcolor[i].red = rw->rookies.color[i].red;
    rw->rookies.fadestartcolor[i].blue = rw->rookies.color[i].blue;
    rw->rookies.fadestartcolor[i].green = rw->rookies.color[i].green;
    rw->rookies.fadeendcolor[i].red = rw->rookies.targetcolor[i].red;
    rw->rookies.fadeendcolor[i].blue = rw->rookies.targetcolor[i].blue;
    rw->rookies.fadeendcolor[i].green = rw->rookies.targetcolor[i].green;
  }
  input_hook = fade_ip;
  register_timeout((Widget)rw, FADE_TICKS);
}

void fade_out_black(RookiesWidget rw, int x)
{
  int i;

  rw->rookies.count = 0;
  rw->rookies.speed = x;
  for (i = 0; i < NCOLORS; i++) {
    rw->rookies.fadestartcolor[i].red = rw->rookies.color[i].red;
    rw->rookies.fadestartcolor[i].blue = rw->rookies.color[i].blue;
    rw->rookies.fadestartcolor[i].green = rw->rookies.color[i].green;
    rw->rookies.fadeendcolor[i].red = 0;
    rw->rookies.fadeendcolor[i].blue = 0;
    rw->rookies.fadeendcolor[i].green = 0;
  }
  input_hook = fade_ip;
  register_timeout((Widget)rw, FADE_TICKS);
}

void fade_out_white(RookiesWidget rw, int x)
{
  int i;

  rw->rookies.count = 0;
  rw->rookies.speed = x;
  for (i = 0; i < NCOLORS; i++) {
    rw->rookies.fadestartcolor[i].red = rw->rookies.color[i].red;
    rw->rookies.fadestartcolor[i].blue = rw->rookies.color[i].blue;
    rw->rookies.fadestartcolor[i].green = rw->rookies.color[i].green;
    rw->rookies.fadeendcolor[i].red = 0xf * FACTOR;
    rw->rookies.fadeendcolor[i].blue = 0xf * FACTOR;
    rw->rookies.fadeendcolor[i].green = 0xf * FACTOR;
  }
  input_hook = fade_ip;
  register_timeout((Widget)rw, FADE_TICKS);
}

void fade_in_white(RookiesWidget rw, int x)
{
  int i;

  rw->rookies.count = 0;
  rw->rookies.speed = x;
  for (i = 0; i < NCOLORS; i++) {
    rw->rookies.fadestartcolor[i].red = 0xf * FACTOR;
    rw->rookies.fadestartcolor[i].blue = 0xf * FACTOR;
    rw->rookies.fadestartcolor[i].green = 0xf * FACTOR;
    rw->rookies.fadeendcolor[i].red = rw->rookies.targetcolor[i].red;
    rw->rookies.fadeendcolor[i].blue = rw->rookies.targetcolor[i].blue;
    rw->rookies.fadeendcolor[i].green = rw->rookies.targetcolor[i].green;
  }
  input_hook = fade_ip;
  register_timeout((Widget)rw, FADE_TICKS);
}

void open_curtain_ip(Widget w, int last_key)
{
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  if (--rw->rookies.curtain_count <= 0) {
    input_hook = NULL;
    rw->rookies.curtain_moving = False;
    register_work_proc(w);
  } else {
    register_timeout((Widget)rw, CURTAIN_TICKS);
  }
  send_redraw_event(rw, CURTAIN_X, CURTAIN_Y, CURTAIN_WIDTH, CURTAIN_HEIGHT);
}

void open_curtain(RookiesWidget rw)
{
  rw->rookies.curtain_count = MAX_CURTAIN - 1;
  rw->rookies.curtain_moving = True;
  rw->rookies.curtain_opened = True;
  input_hook = open_curtain_ip;
  register_timeout((Widget)rw, CURTAIN_TICKS);
}

void close_curtain_ip(Widget w, int last_key)
{
  RookiesWidget rw;

  rw = (RookiesWidget)w;
  if (++rw->rookies.curtain_count >= MAX_CURTAIN - 1) {
    input_hook = NULL;
    rw->rookies.curtain_moving = False;
    register_work_proc(w);
  } else {
    register_timeout((Widget)rw, CURTAIN_TICKS);
  }
  send_redraw_event(rw, CURTAIN_X, CURTAIN_Y, CURTAIN_WIDTH, CURTAIN_HEIGHT);
}

void close_curtain(RookiesWidget rw)
{
  rw->rookies.curtain_count = 0;
  rw->rookies.curtain_opened = False;
  rw->rookies.curtain_moving = True;
  input_hook = close_curtain_ip;
  register_timeout((Widget)rw, CURTAIN_TICKS);
}

void change_destination_and_esc(RookiesWidget rw)
{
#if 0
  if (rw->rookies.current_display == 0)
    rw->rookies.current_display = 1;
  else
    rw->rookies.current_display = 0;
#endif
  current.escape_normal = False;
  send_redraw_event(rw, 0, 0, 640, 400);
}

void change_destination_and_esc_to_default(RookiesWidget rw)
{
#if 0
  if (rw->rookies.current_display == 0)
    rw->rookies.current_display = 1;
  else
    rw->rookies.current_display = 0;
#endif
  current.escape_normal = True;
  send_redraw_event(rw, 0, 0, 640, 400);
}

void read_idxfile(char *s)
{
  idx_buf = expand_idx_file(s);
}

void read_pixfile(char *s)
{
  pix_buf = expand_pix_file(s);
}

void animation_workproc(XtPointer client_data, XtIntervalId *id)
{
  /* ���˥᡼������Ѥ� workproc �ϰ��������˸ƤФ�롣 */
  /* �Ǹ�� register_work_proc ��Ƥ٤��ɤ� */
  /* ��������� func_17 ����ߤ��򤫤�� */
  Widget w = (Widget)client_data;
  RookiesWidget rw = (RookiesWidget)w;
  Display *display = XtDisplay(w);
  GC gc = rw->rookies.gc;
  Window win = XtWindow(w);
  int top = rw->rookies.anim->top;
  int bottom = rw->rookies.anim->bottom;
  int current_line = rw->rookies.anim->current;
  int speed = rw->rookies.anim->speed;
  int width = rw->rookies.anim->width;
  int vheight = rw->rookies.anim->vheight;
  if (top == current_line) {
    /* �ǽ�θƤӽФ� */
    /* ��ꤢ�������������� */
    XCopyArea(display, rw->rookies.anim->pixmap,
	      win, gc,
	      0, current_line, width, vheight,
	      current.graphic_origin_x, current.graphic_origin_y); 
    XCopyArea(display, rw->rookies.anim->pixmap,
	      rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	      0, current_line, width, vheight,
	      current.graphic_origin_x, current.graphic_origin_y);
    if (top >= bottom)
      current_line -= speed;
    else
      current_line += speed;
  } else if (top >= bottom) {
    /* ���ؤȥ��������� */
    current_line -= speed;
    XCopyArea(display, win,
	      win, gc,
	      current.graphic_origin_x, current.graphic_origin_y,
	      width, vheight - speed,
	      current.graphic_origin_x, current.graphic_origin_y + speed); 
    XCopyArea(display, rw->rookies.pixmap[MAIN_SCREEN(rw)],
	      rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	      current.graphic_origin_x, current.graphic_origin_y,
	      width, vheight - speed,
	      current.graphic_origin_x, current.graphic_origin_y + speed);
    XCopyArea(display, rw->rookies.anim->pixmap,
	      win, gc,
	      0, current_line, width, speed,
	      current.graphic_origin_x, current.graphic_origin_y); 
    XCopyArea(display, rw->rookies.anim->pixmap,
	      rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	      0, current_line, width, speed,
	      current.graphic_origin_x, current.graphic_origin_y);
  } else {
    /* ��ؤȥ��������� */
    current_line += speed;
    XCopyArea(display, win,
	      win, gc,
	      current.graphic_origin_x, current.graphic_origin_y + speed,
	      width, vheight - speed,
	      current.graphic_origin_x, current.graphic_origin_y); 
    XCopyArea(display, rw->rookies.pixmap[MAIN_SCREEN(rw)],
	      rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	      current.graphic_origin_x, current.graphic_origin_y + speed,
	      width, vheight - speed,
	      current.graphic_origin_x, current.graphic_origin_y);
    XCopyArea(display, rw->rookies.anim->pixmap,
	      win, gc,
	      0, current_line + vheight - speed, width, speed,
	      current.graphic_origin_x, current.graphic_origin_y+ vheight - speed); 
    XCopyArea(display, rw->rookies.anim->pixmap,
	      rw->rookies.pixmap[MAIN_SCREEN(rw)], gc,
	      0, current_line + vheight - speed, width, speed,
	      current.graphic_origin_x, current.graphic_origin_y + vheight - speed);
  }
  rw->rookies.anim->current = current_line;
  send_redraw_event(rw, 0, 0, 0, 0);
  /* ��λ��Ƚ�� */
  if ((top >= bottom && current_line <= bottom) || 
      (top <= bottom && current_line >= bottom)) {
    register_work_proc(w);
  } else {
    /* ³�� */
    void start_animation(Widget);
    start_animation(w);
  }
}

void start_animation(Widget w)
{
  /* ���˥᡼������Ѥ� workproc ����Ͽ */
  RookiesWidget rw = (RookiesWidget)w;
  Display *display = XtDisplay(rw);
  XtAppContext xt = XtDisplayToApplicationContext(display);
  rw->rookies.anim->timer = XtAppAddTimeOut(xt, ANIM_TICKS, animation_workproc, rw);
}

/* OK */
int func_00(RookiesWidget rw)
{
  int ip;
  ip = current.ip;
  exit(scenario_buf[ip + 1]);
  current.ip += 2;
  return CONTINUE;
}

/* OK */
int func_01(RookiesWidget rw)
{
  /* �ץ���ץȤ�ɽ������ (text) */
  /* workproc ��ä��������Ԥ� */
  /* system_menu ������ΤϤ������� */
  newline(rw);
  current.ip++;
  return SLEEP;
}

/* OK */
int func_02(RookiesWidget rw)
{
  /* draw mig file */
  int ip;
  int j;
  char *filename;
  char color;

  ip = current.ip;
  color = scenario_buf[ip + 1];
  filename = canonicalize_filename(scenario_buf + ip + 2);
  draw_mig(rw, color, filename);
  free(filename);
  for (j = 2; scenario_buf[ip + j] != '\0'; j++);

  current.ip += j + 1;
  return CONTINUE;
}

/* OK */
int func_03(RookiesWidget rw)
{
  /* jump */
  int x;
  int ip;

  ip = current.ip;
  x = scenario_buf[ip + 2] << 8 | scenario_buf[ip + 1];
  current.ip = x;
  return CONTINUE;
}

/* OK */
int func_04(RookiesWidget rw)
{
  int x;
  int ip;

  ip = current.ip;
  x = scenario_buf[ip + 2] << 8 | scenario_buf[ip + 1];
  current.stack[current.stackptr++] = ip + 3;
  current.ip = x;
  return CONTINUE;
}

/* OK */
int func_05(RookiesWidget rw)
{
  int end, ind, len;
  int i;
  int c;
  int ip;

  ip = current.ip;
  menu_status.item_num = scenario_buf[ip + 1];
  menu_status.val = scenario_buf[ip + 2];
  menu_status.menu_items = (char **)calloc(sizeof(char *),
					   menu_status.item_num);
  menu_status.current_selection = 0;
  ind = ip + 3;
  for (i = 0; i < scenario_buf[ip + 1]; i++) {
    len = 0;
    while (scenario_buf[ind + len] != 1)
      len += 2;
    len++;
    menu_status.menu_items[i] = (char *)malloc(len);
    menu_status.menu_items[i][0] = '\0';
    ind += len;
  }
  end = ind;
  ind = ip + 3;
  for (i = 0; i < scenario_buf[ip + 1]; i++) {
    len = 0;
    while (scenario_buf[ind + len] != 1) {
      c = jis2euc(scenario_buf[ind + len + 1], scenario_buf[ind + len]);
      menu_status.menu_items[i][len + 1] = c & 0xff;
      menu_status.menu_items[i][len] = (c >> 8) & 0xff;
      len += 2;
    }
    menu_status.menu_items[i][len] = '\0';
    len++;
    ind += len;
  }
  menu_status.start = 0;
  menu_status.end = menu_status.item_num - 1;

  menu(rw, menu_status.menu_items);

  current.ip += end - ip;
  return SLEEP;			/* ��˥塼�����Υ롼������̤��Ѱդ��� */
}

/* PARSE ONLY */
int func_06(RookiesWidget rw)
{
  int j;
  int first_num, second_num;
  unsigned char *first_str, *second_str;
  int ip;

  ip = current.ip;
  first_num = scenario_buf[ip + 1];
  first_str = scenario_buf + ip + 2;
  for (j = 2; scenario_buf[ip + j] != '\0'; j++);
  j++;
  second_num = scenario_buf[ip + j];
  second_str = scenario_buf + ip + j + 1;
  for (j += 2; scenario_buf[ip + j] != '\0'; j++);
  j++;
#if 0
  setup_zurizuri(first_num, first_str, second_num, second_str)
#endif
  current.ip += j;
  return CONTINUE;
}

/* PARSE ONLY */
int func_07(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
#if 0
  switch (scenario_buf[ip + 1]) {
  case 1:
    zurizuri_scroll();
    break;
  case 2:
    scroll_up_two_screen();
    break;
  }
#endif
  current.ip += 2;
  return CONTINUE;		/*�����ʤ� YIELD ���֤��� SLEEP ���֤� */
}

/* OK */
int func_08(RookiesWidget rw)
{
  free_ani_data(rw);
  current.ip++;
  return CONTINUE;
}

/* OK */
int func_09(RookiesWidget rw)
{
  /* arithmetics */
  int op, x, y;
  int ip;

  ip = current.ip;
  op = scenario_buf[ip + 2];
  x = scenario_buf[ip + 1];
  y = scenario_buf[ip + 3];
  switch (op) {
  case 0:			/* load immediate */
    current.variable[x] = y;
    break;
  case 1:			/* add immediate */
    current.variable[x] += y;
    break;
  case 2:			/* sub immediate */
    current.variable[x] -= y;
    break;
  case 3:			/* mul immediate */
    current.variable[x] *= y;
    break;
  case 4:			/* honto ha wari-zan? */
    assert(y != 0);
    current.variable[x] /= y;
    break;
  case 5:			/* mod immediate */
    assert(y != 0);
    current.variable[x] %= y;
    break;
  case 6:			/* hmm... rand?*/
    assert(y != 0);
    current.variable[x] = random() % y;
    break;
  case 7:			/* mov */
    current.variable[x] = current.variable[y];
    break;
  case 8:			/* add */
    current.variable[x] += current.variable[y];
    break;
  case 9:			/* sub */
    current.variable[x] -= current.variable[y];
    break;
  case 0xa:			/* mul */
    current.variable[x] *= current.variable[y];
    break;
  case 0xb:			/* koremo wari-zan ? */
    assert(current.variable[y] != 0);
    current.variable[x] /= current.variable[y];
    break;
  case 0xc:			/* mod */
    assert(current.variable[y] != 0);
    current.variable[x] %= current.variable[y];
    break;
  case 0xd:			/* hmm... rand??*/
    assert(current.variable[y] != 0);
    current.variable[x] = random() % current.variable[y];
    break;
  }
  current.ip += 4;
  return CONTINUE;
}

/* OK */
int func_0a(RookiesWidget rw)
{
  int op;
  int x, y, z;
  int ip;
  int flag;

  ip = current.ip;
  op = scenario_buf[ip + 2];
  x = scenario_buf[ip + 1];
  y = scenario_buf[ip + 3];
  z = scenario_buf[ip + 5] << 8 | scenario_buf[ip + 4];
  flag = 0;
  switch(op) {
  case 1:			/* je immediate */
    flag = current.variable[x] != y;
    break;
  case 2:			/* jne immediate */
    flag = current.variable[x] == y;
    break;
  case 3:			/* jg immediate */
    flag = current.variable[x] <= y;
    break;
  case 4:			/* jl immediate */
    flag = current.variable[x] >= y;
    break;
  case 5:			/* je */
    flag = current.variable[x] != current.variable[y];
    break;
  case 6:			/* jne */
    flag = current.variable[x] == current.variable[y];
    break;
  case 7:			/* jg */
    flag = current.variable[x] <= current.variable[y];
    break;
  case 8:			/* jl */
    flag = current.variable[x] >= current.variable[y];
    break;
  }
  if (flag)
    current.ip = z;
  else
    current.ip += 6;
  return CONTINUE;
}

/* OK */
int func_0b(RookiesWidget rw)
{
  int x, y;
  int ip;

  ip = current.ip;
  x = scenario_buf[ip + 2] << 8 | scenario_buf[ip + 1];
  y = scenario_buf[ip + 4] << 8 | scenario_buf[ip + 3];
  current.graphic_origin_x = (unsigned)x;
  current.graphic_origin_y = (unsigned)y;
  current.ip += 5;
  return CONTINUE;
}

/* OK */
int func_0c(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  current.dialog_box_x0 = (unsigned)scenario_buf[ip + 1];
  current.dialog_box_y0 = (unsigned)scenario_buf[ip + 2];
  current.dialog_box_x1 = (unsigned)scenario_buf[ip + 3];
  current.dialog_box_y1 = (unsigned)scenario_buf[ip + 4];
  current.cursor_x = current.dialog_box_x0;
  current.cursor_y = current.dialog_box_y0;
  current.ip += 5;
  return CONTINUE;
}

/* OK */
int func_0d(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  switch (scenario_buf[ip + 1]) {
  case 0:
    current.show_prompt = True;
    break;
  case 1:
    current.show_prompt = False;
    break;
  case 2:
    current.timeout_confirm = False;
    break;
  case 3:
    current.timeout_confirm = True;
    break;
  }
  current.ip += 2;
  return CONTINUE;
}

/* OK */
int func_0e(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  exec_file(scenario_buf + ip + 1);
#if 0
  for (j = 1; scenario_buf[ip + j] != '\0'; j++);
#endif
  current.ip = 0;
  return CONTINUE;
}

/* PARSE ONLY */
int func_0f(RookiesWidget rw)
{
  int j;
  int r;
  int ip;

  ip = current.ip;
  r = 0;
  switch (scenario_buf[ip + 1]) {
    /* (str) */
  case 0:
#if 0
    play_bgm(scenario_buf + ip + 2);
#endif
    for (j = 2; scenario_buf[ip + j] != '\0'; j++);
    r = j + 1;
    break;
    /* (void) */
  case 1:
#if 0
    int_60_0();
#endif
    r = 2;
    break;
  case 2:
#if 0
    int_60_1();
#endif
    r = 2;
    break;
  case 7:
#if 0
    int_60_0D();
#endif
    r = 2;
    break;
  case 8:
#if 0
    int_60_1A();
#endif
    r = 2;
    break;
  case 9:
#if 0
    int_60_1B();
#endif
    r = 2;
    break;
    /* (char) */
  case 3:
#if 0
    int_60_2_0(scenario_buf[ip + 2]);
#endif
    r = 3;
    break;
    /* (char) */
  case 4:
#if 0
    int_60_2_1(scenario_buf[ip + 2]);
#endif
    r = 3;
    break;
    /* (char) */
  case 5:
#if 0
    int_60_0C(scenario_buf[ip + 2]);
#endif
    r = 3;
    break;
  case 6:
#if 0
    int_60_19(scenario_buf[ip + 2]);
#endif
    r = 3;
    break;
  }
  current.ip += r;
  return CONTINUE;
}

/* OK */
int func_10(RookiesWidget rw)
{
  /* func_01 �Ȱ㤦�Τ� cursor ��ɽ�����ʤ��Ȥ��� */
  wait_for_key();
  current.ip++;
  return SLEEP;
}

/* OK */
int func_11(RookiesWidget rw)
{
  int op;
  int speed;
  int ip;

  ip = current.ip;
  op = scenario_buf[ip + 1];
  speed = scenario_buf[ip + 2];	/* �������礭���ۤ�®�� */
  switch (op) {
  case 1:			/* OK */
    fade_in_black(rw, speed);
    break;
  case 2:			/* OK */
    fade_out_black(rw, speed);
    break;
  case 3:			/* OK */
    fade_in_white(rw, speed);
    break;
  case 4:			/* OK */
    fade_out_white(rw, speed);
    break;
  case 5:			/* OK */
    open_curtain(rw);
    break;
  case 6:			/* OK */
    close_curtain(rw);
    break;
  default:
    break;
  }

  current.ip += 3;
  return SLEEP;
}

/* PARSE ONLY */
int func_12(RookiesWidget rw)
{
  int j;
  int ip;

  ip = current.ip;
  for (j = 1; scenario_buf[ip + j] != '\0'; j++);
  current.ip += j + 1;
  return CONTINUE;
}

/* OK */
int func_13(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  current.text_color = (scenario_buf[ip + 1] >> 5) & 0x7;
  current.ip += 2;
  return CONTINUE;
}

/* OK */
int func_14(RookiesWidget rw)	/* idx */
{
  int j;
  int ip;
  char *filename;

  ip = current.ip;
  filename = canonicalize_filename(scenario_buf + ip + 1);
  read_idxfile(filename);
  free(filename);
  for (j = 1; scenario_buf[ip + j] != '\0'; j++);
  current.ip += j + 1;
  return CONTINUE;
}

/* OK */
int func_15(RookiesWidget rw)	/* pix */
{
  int j;
  int ip;
  char *filename;

  ip = current.ip;
  filename = canonicalize_filename(scenario_buf + ip + 1);
  read_pixfile(filename);
  free(filename);
  for (j = 1; scenario_buf[ip + j] != '\0'; j++);
  current.ip += j + 1;
  return CONTINUE;
}

/* OK */
int func_16(RookiesWidget rw)
{
  int r;
  int i;
  char buf[0x100];
  int w, x, y, z;
  int speed;
  int ip;

  ip = current.ip;
  r = 0;
  switch (scenario_buf[ip + 1]) {
    /* (char, char, char, char, ...) */
  case 0: case 1:		/* PARSE ONLY */
    i = 0;
    if (scenario_buf[ip + 2] < scenario_buf[ip + 3]) {
      for (i = 0; i < scenario_buf[ip + 3] - scenario_buf[ip + 2]; i++)
	buf[i] = scenario_buf[ip + 4 + i];
    }
#if 0
    printf("0x%02X 0x%02X 0x%02X 0x%02X\n",
	   scenario_buf[ip], scenario_buf[ip + 1],
	   scenario_buf[ip + 2], scenario_buf[ip + 3]);
#endif
    r = 4 + i;
    break;
    /* (char, int, int, int, char) */
  case 2:			/* OK */
    w = scenario_buf[ip + 2];
    x = scenario_buf[ip + 4] << 8 | scenario_buf[ip + 3];
    y = scenario_buf[ip + 6] << 8 | scenario_buf[ip + 5];
    z = scenario_buf[ip + 8] << 8 | scenario_buf[ip + 7];
    speed = scenario_buf[ip + 9];
#if 0
    printf("0x%02X 0x%02X 0x%02X 0x%04X 0x%04X 0x%04X 0x%02X\n",
	   scenario_buf[ip], scenario_buf[ip + 1], w, x, y, z,
	   scenario_buf[ip + 9]);
#endif
    /*
       w: rookies �ǤϾ�� 0
       x: ���������뤹���ΰ�ι⤵
       y: �������ȥ饤��
       z: ����ɥ饤��
       speed: ���ԡ���
       */
    expand_animation((Widget)rw, x, y, z, speed);
    memcpy(rw->rookies.targetcolor, rw->rookies.anim->color, sizeof(rw->rookies.anim->color));
    start_animation((Widget)rw);
    r = 10;
    break;
  }
  current.ip += r;
  return CONTINUE;		/* ���˥᡼������������� */
}

/* OK */
int func_17(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
#if 0
  printf("0x%02X 0x%02X\n", scenario_buf[ip], scenario_buf[ip + 1]);
#endif
  current.ip += 2;
#if 1
  return SLEEP;			/* ���˥᡼�����ν�λ���Ԥ� */
#else
  return CONTINUE;		/* �Ȥꤢ����̵�� */
#endif
}

/* PARSE ONLY */
int func_18(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
#if 0
  printf("0x%02X\n", scenario_buf[ip]);
#endif
  current.ip++;
  return CONTINUE;
}

/* OK */
int func_19(RookiesWidget rw)
{
  int w, x, y, z;
  int ip;

  ip = current.ip;
  w = scenario_buf[ip + 3] << 8 | scenario_buf[ip + 2];
  x = scenario_buf[ip + 5] << 8 | scenario_buf[ip + 4];
  y = scenario_buf[ip + 7] << 8 | scenario_buf[ip + 6];
  z = scenario_buf[ip + 9] << 8 | scenario_buf[ip + 8];
  switch (scenario_buf[ip + 1]) {
  case 1:			/* ���֤���ᥤ��إ��ԡ� */
    copy_sub_to_main(rw, w, x, y, z);
    break;
  case 2:
    fill_rectangle(rw, w, x, y, z, scenario_buf[ip + 10]);
    break;
  case 3:
    clear_75(rw, w, x, y, z);
    break;
  }
  current.ip += 11;
  return YIELD;
}

/* PARSE ONLY */
int func_1a(RookiesWidget rw)
{
  int r;
  int x;
  int ip;

  ip = current.ip;
  r = 0;
  switch (scenario_buf[ip + 1]) {
    /* (int) */
  case 0:
    x = scenario_buf[ip + 3] << 8 | scenario_buf[ip + 2];
#if 0
    printf("0x%02X 0x%02X 0x%04X\n", scenario_buf[ip], scenario_buf[ip + 1], x);
#endif
    r = 4;
    break;
    /* (void) */
  case 1: case 3:
#if 0
    printf("0x%02X 0x%02X\n", scenario_buf[ip], scenario_buf[ip + 1]);
#endif
    r = 2;
    break;
    /* (char) */
  case 2:
#if 0
    printf("0x%02X 0x%02X 0x%02X\n",
	   scenario_buf[ip], scenario_buf[ip + 1], scenario_buf[ip + 2]);
#endif
    r = 3;
    break;
  }
  current.ip += r;
  return CONTINUE;
}

/* OK */
int func_1b(RookiesWidget rw)
{
  current.ip = current.stack[--current.stackptr];
  return CONTINUE;
}

/* OK */
int func_1c(RookiesWidget rw)
{
  set_palette(rw);
  current.ip++;
  return CONTINUE;
}

/* OK */
int func_1d(RookiesWidget rw)
{
  /* ���Ϥ�̵�뤷�Ƥ褤 */
  int ip;

  ip = current.ip;
  make_delay(rw, scenario_buf[ip + 1]);
  current.ip += 2;
  return SLEEP;			/* �����ॢ���Ȥ��Ԥ� */
}

/* OK */
int func_1e(RookiesWidget rw)
{
  int r;
  int ip;
  int fd;
  int status;

  ip = current.ip;
  r = 0;
  status = CONTINUE;
  switch (scenario_buf[ip + 1]) {
  case 1:			/* PARSE ONLY */
#if 0
    input_name();
#endif
    r = 2;
    status = CONTINUE;
    break;
    /* (char) */
  case 6:			/* OK */
    if ((fd = open(HOEHOEDAT, O_RDWR | O_CREAT, 0644)) > 0) {
      write(fd, &scenario_buf[ip + 2], 1);
      close(fd);
    } else {
      fprintf(stderr, "Couldn't write \"" HOEHOEDAT
	      "\"\nCheck directory permission");
    }
    r = 3;
    status = CONTINUE;
    break;
    /* (void) */
  case 2: case 3: case 4: case 5: /* PARSE ONLY */
#if 0
    printf("0x%02X 0x%02X\n", scenario_buf[ip], scenario_buf[ip + 1]);
#endif
    r = 2;
    status = CONTINUE;
    break;
  case 7:			/* OK */
    change_destination_and_esc(rw);
    r = 2;
    status = YIELD;
    break;
  case 8:			/* OK */
    change_destination_and_esc_to_default(rw);
    r = 2;
    status = YIELD;
    break;
  case 9:			/* OK */
    save_load_menu(rw);		/* �¤ϥ����ɤ��� */
    status = SLEEP;
    r = 2;
    break;
  }
  current.ip += r;
  return status;
}

/* PARSE ONLY */
int func_1f(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
#if 0
  change_diskette(scenario_buf[ip + 1]);
#endif
  current.ip += 2;
  return CONTINUE;
}

/* OK */
int func_20(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  switch (scenario_buf[ip + 1]) {
  case 0:
    current.system_menu_enabled = True;
    break;
  case 1:
    current.system_menu_enabled = False;
    break;
  case 2:
    memcpy(&saved, &current, sizeof(current));
    break;
  }
  current.ip += 2;
  return CONTINUE;
}

/* OK */
int func_80(RookiesWidget rw)
{
  int ip;

  ip = current.ip;
  refer_str(rw, scenario_buf[ip + 1]);
  current.ip += 2;
  return YIELD;
}

/* OK */
int func_others(RookiesWidget rw)
{
  char c[3];
  int ip;

  if (current.cursor_y >= current.dialog_box_y1) {
    current.cursor_visible = True;
    register_timeout((Widget)rw, CURSOR_BLINK);
    input_hook = newline_ip;
    return SLEEP;
  }
  ip = current.ip;
  c[2] = '\0';
  c[0] = scenario_buf[ip + 1] & 0x7f;
  c[1] = scenario_buf[ip] & 0x7f;
  display_letter(rw, c);
  send_redraw_event(rw, 0, 0, 0, 0);
  current.ip += 2;
  return YIELD;
}

int (*funcs[])(RookiesWidget rw) = {
  func_00, func_01, func_02, func_03, func_04, func_05, func_06, func_07,
  func_08, func_09, func_0a, func_0b, func_0c, func_0d, func_0e, func_0f,
  func_10, func_11, func_12, func_13, func_14, func_15, func_16, func_17,
  func_18, func_19, func_1a, func_1b, func_1c, func_1d, func_1e, func_1f,
  func_20,
};

int dispatch(RookiesWidget rw)
{
  int c;
  int (*func)(RookiesWidget);

  c = scenario_buf[current.ip];
  if (c <= 0x20)
    func = funcs[c];
  else if (c == 0x80)
    func = func_80;
  else
    func = func_others;
  return (*func)(rw);
}

int scenario(RookiesWidget rw)
{
  int status;

  status = CONTINUE;
  while (status == CONTINUE) {
    if (scenario_buf == NULL)
      scenario_buf = expand_scenario_file(scenario_filename);
    status = dispatch(rw);
  }
  return status;
}

void scenario_initialize(void)
{
  int i, j;
  static context_t *contexts[] = {&current, &saved};
  static int ncontexts = sizeof(contexts) / sizeof(context_t *);
  int fd;

  for (j = 0; j < ncontexts; j++) {
    for (i = 0; i < NVAL; i++)
      contexts[j]->variable[i] = 0;
    memset(contexts[j]->filename, '\0', PATHLEN);
    contexts[j]->ip = 0;
    for (i = 0; i < CALLSTACKLEN; i++)
      contexts[j]->stack[i] = 0;
    contexts[j]->stackptr = 0;
    contexts[j]->show_prompt = True;
    contexts[j]->escape_normal = True;
    contexts[j]->system_menu_enabled = False;
  }
  if ((fd = open(HOEHOEDAT, O_RDONLY)) >= 0) {
    char c;
    read(fd, &c, 1);
    close(fd);
    current.variable[255] = c;
  }
  scenario_filename = strdup("ipl.scp");
  scenario_buf = NULL;
}

/* */

static void die(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  XtCallCallbacks(w, XtNdie, NULL);
}

static void leftevent(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, LEFT);
}

static void rightevent(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, RIGHT);
}

static void upevent(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, UP);
}

static void downevent(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, DOWN);
}

static void cancel(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, CANCEL);
}

static void confirm(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, CONFIRM);
}

static void escape(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  if (input_hook != NULL)
    (*input_hook)(w, ESCAPE);
}

static void speedctl(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
}

static void motion(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  query_mouse_pointer(w);
  if (input_hook != NULL)
    (*input_hook)(w, MOTION);
}

void timeout_handler(Widget w)
{
  if (input_hook != NULL)
    (*input_hook)(w, EMPTY);
}

void RookiesInitialize(Widget w)
{
  Pixmap pixmap;
  int width, height;
  int depth;
  Display *display;
  int screen;
  GC gc;
  RookiesWidget rw;
  Colormap colormap;
  int i;
  unsigned long pixels[NCOLORS];
  unsigned long textpixels[NTXTCOLS];
  XGCValues values;
  unsigned long valuemask;

  width = RookiesGetWidth(w);
  height = RookiesGetHeight(w);
  display = XtDisplay(w);
  screen = DefaultScreen(display);
  depth = DefaultDepth(display, screen);
  gc = DefaultGC(display, screen);
  rw = (RookiesWidget)w;
  pixmap = XCreatePixmap(display, XtWindow(w), width, height, depth);
  XFillRectangle(display, pixmap, gc, 0, 0, width, height);
  rw->rookies.pixmap[0] = pixmap;
  pixmap = XCreatePixmap(display, XtWindow(w), width, height, depth);
  XFillRectangle(display, pixmap, gc, 0, 0, width, height);
  rw->rookies.pixmap[1] = pixmap;
  colormap = rw->rookies.colormap = DefaultColormap(display, screen);

  for (i = 0; i < NTXTCOLS; i++) {
    XColor scr_def, exact_def;

    XAllocNamedColor(display, colormap, textcolnames[i], &scr_def, &exact_def);
    textpixels[i] = scr_def.pixel;
    values.foreground = textpixels[i];
    values.font = rw->rookies.font->fid;
    valuemask = GCForeground | GCFont;
    rw->rookies.textgc[i] = XCreateGC(display, XtWindow(rw), valuemask, &values);
  }
  for (i = 0; i < NCOLORS; i++) {
    if (!XAllocColorCells(display, colormap, False, NULL, 0, &pixels[i], 1))
      break;
    rw->rookies.color[i].pixel = pixels[i];
    rw->rookies.color[i].red = 0;
    rw->rookies.color[i].blue = 0;
    rw->rookies.color[i].green = 0;
    rw->rookies.color[i].flags = DoRed|DoGreen|DoBlue;
  }
  if (i != NCOLORS) {
    fprintf(stderr, "Color Cell Shortage\nexiting...\n");
    exit(1);
  }
  rw->rookies.texton = current.show_text = True;
  rw->rookies.inmenu = False;
  rw->rookies.curtain_opened = True;
  rw->rookies.curtain_count = 0;
  rw->rookies.curtain_moving = False;
  rw->rookies.current_display = 0;
  rw->rookies.display_flipped = False;
  input_hook = NULL;
  input_timeout.tv_sec = 0;
  input_timeout.tv_usec = 0;
  mouse_loc.x = 0;
  mouse_loc.y = 0;

  menu_status.menu_items = NULL;
  menu_status.val = 0;
  menu_status.item_num = 0;
  menu_status.current_selection = 0;

  rw->rookies.anim = NULL;

  rw->rookies.curtain_rect_num = CURTAIN_HEIGHT / MAX_CURTAIN;
  if (CURTAIN_HEIGHT % MAX_CURTAIN != 0)
    rw->rookies.curtain_rect_num++;
  rw->rookies.curtain_rect = (XRectangle *)calloc(rw->rookies.curtain_rect_num,
						  sizeof(XRectangle));
  register_work_proc(w);
}
