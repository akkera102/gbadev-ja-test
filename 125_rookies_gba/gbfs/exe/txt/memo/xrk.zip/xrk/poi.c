#include <stdio.h>
#include <stdlib.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysymdef.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/StringDefs.h>
#include <X11/Xlocale.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <sys/time.h>
#include <unistd.h>
#include "rookies.h"
#include "rookiesstr.h"
#include "scenario.h"
#include "poi.h"

static Atom protocols[1];

struct _resources_t {
} resources;

static XrmOptionDescRec options[] = {
};

static XtResource application_resources[] = {
};

static void event(), die(), save();

static XtActionsRec actions[] = {
  {"event", event},
  {"save", save},
  {"die", die},
};

String fallback_resources[] = {
  "*font: kanji16",
  NULL
};

static char TranslationTable[] = "\
<Message>WM_PROTOCOLS: event()\n\
";

typedef struct {
  int id;
  String name;
  Boolean trap;
  Widget widget;
} ButtonRec;

void main(int argc, char **argv)
{
  XtAppContext xtcontext;
  Display *display;
  Visual *visual;
  int screen;
  int depth;
  Widget top, rookies_widget;
  Arg args[6];
  int n;
  int width = 640;
  int height = 400;

  XtSetLanguageProc(NULL, NULL, NULL);

  top = XtOpenApplication(&xtcontext, "Rookies",
			  options, XtNumber(options), &argc, argv,
			  fallback_resources, sessionShellWidgetClass,
			  NULL, 0);
  XtGetApplicationResources(top, (XtPointer)&resources,
			    application_resources,
			    XtNumber(application_resources),
			    NULL, 0);
  XtAddCallback(top, XtNdieCallback, die, NULL);
  XtAddCallback(top, XtNsaveCallback, die, NULL);
  n = 0;
  XtSetArg(args[n], XtNminWidth, width); n++;
  XtSetArg(args[n], XtNminHeight, height); n++;
  XtSetArg(args[n], XtNmaxWidth, width); n++;
  XtSetArg(args[n], XtNmaxHeight, height); n++;
  XtSetArg(args[n], XtNwidth, width); n++;
  XtSetArg(args[n], XtNheight, height); n++;
  XtSetValues(top, args, n);
  XtAppAddActions(XtWidgetToApplicationContext(top),
		  actions, XtNumber(actions));
  XtOverrideTranslations(top, XtParseTranslationTable(TranslationTable));
  display = XtDisplay(top);
  screen = DefaultScreen(display);
  visual = DefaultVisual(display, screen);
  depth = DefaultDepth(display, screen);

  if (depth != 8) {
    fprintf(stderr, "8-bit Color Display is needed\n");
    exit(1);
  }

  rookies_widget = XtCreateManagedWidget("rookies", rookiesWidgetClass, top, NULL, 0);
  XtRealizeWidget(top);
  protocols[0] = XInternAtom(display, "WM_DELETE_WINDOW", False);
  XSetWMProtocols(display, XtWindow(top),
		  protocols, XtNumber(protocols));
  XStoreName(display, XtWindow(top), "Rookies");
  XSetIconName(display, XtWindow(top), "Rookies");

  RookiesInitialize(rookies_widget);

  scenario_initialize();

  XtAddCallback(rookies_widget, XtNdie, die, NULL);

  XtAppMainLoop(xtcontext);
}

static void die(Widget w, XtPointer client_data, XtPointer call_data)
{
  Display *display = XtDisplay(w);
  XtDestroyWidget(w);
  XCloseDisplay(display);
  exit(0);
}

static void save(Widget w, XtPointer client_data, XtPointer call_data)
{
}

static void event(Widget w, XEvent *event, String *params, Cardinal *num_params)
{
  Display *display = XtDisplay(w);
  Arg arg;

  if (event->type == ClientMessage && event->xclient.data.l[0] != protocols[0]) {
    XBell(display, 0);
  } else {
    XtSetArg(arg, XtNjoinSession, False);
    XtSetValues(w, &arg, 1);
    die(w, NULL, NULL);
  }
}
