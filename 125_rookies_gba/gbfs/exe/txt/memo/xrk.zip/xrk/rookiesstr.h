#ifndef _RookiesStr_H_
#define _RookiesStr_H_

#define XtNup "up"
#define XtNdown "down"
#define XtNright "right"
#define XtNleft "left"
#define XtNcancel "cancel"
#define XtNconfirm "confirm"
#define XtNescape "escape"
#define XtNdie "die"
#define XtNspeedctl "speedctl"
#define XtNmotion "motion"

#endif
