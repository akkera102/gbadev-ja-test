#ifndef _jis_h_
#define _jis_h_

int msc2jis(int a1);
int jis2msc(int h, int l);
int jis2euc(int h, int l);

#endif
