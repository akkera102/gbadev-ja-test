#include <stdio.h>
#include <stdlib.h>
#include "exp.h"

static int bitp;

static int msb(int a)
{
  int m;
  unsigned int val = (unsigned int)a;

  for (m = -1; val != 0; m++, val >>= 1);
  return m;
}

#if 0
static int lsb(int a)
{
  int l;
  unsigned int val = (unsigned int)a;

  if (val == 0)
    return -1;
  for (l = 0; (val & 1) == 0; l++, val >>= 1);
  return l;
}
#endif

static int getbit(FILE *fp)
{
  static char c;
  if (bitp <= 0) {
    bitp = 8;
    fread(&c, 1, 1, fp);
  }
  bitp--;
  return (c & (1 << bitp)) ? 1 : 0;
}

static unsigned int getbits(FILE *fp, int a1)
{
  int r;
  int i;

  r = 0;
  for (i = 0; i < a1; i++) {
    r <<= 1;
    r += getbit(fp);
  }
  return r;
}

void expand_file(FILE *fp, unsigned char *op, int bufsize)
{
  int l1;
  unsigned int l4;
  unsigned int l3, l5;
  unsigned char l7;

  bitp = 0;
  for (l1 = 0; l1 < bufsize;) {
    if (getbits(fp, 1) == 0) {
      /* 1-bit yonde, 0 dattara, 8-bit yonde shutsuryoku */
      op[l1] = getbits(fp, 8);
      l1++;
    } else {
      if ((l1 & 0xffff) >= 0 && (l1 & 0xffff) < 0x4000) {
	l4 = msb(l1 & 0xffff) + 1; /* 1 - 16 */
      } else {
	l4 = 0xe;
      }
      l3 = getbits(fp, l4);	/* l4-bits yomu (1 <= l4 <= 14) */
      /* 1 ga deru made, kazoeru */
      for (l7 = 2; l7 != 8; l7++)
	if (getbits(fp, 1) != 0)
	  break;
      /* 1 ga denakattara, 8 bit yomu */
      if (l7 == 8)
	l7 = getbits(fp, 8);
      for (l5 = 0; l5 < l7; l1++, l5++)
	op[l1] = op[l1 - l3];
    }
  }
}
