#ifndef _MIG_H_
#define _MIG_H_
typedef struct _cg_t {
  XImage *ximage;
  char palette[0x30];
  int width, height;
} *cg_t;

extern cg_t expand_picture(Widget, char *);
extern void free_picture(cg_t);
#endif
