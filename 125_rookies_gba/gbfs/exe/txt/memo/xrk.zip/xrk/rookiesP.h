#ifndef _RookiesP_H_
#define _RookiesP_H_

#include "rookies.h"

#define NCOLORS 16
#define NTXTCOLS 8
#define TEXTWIDTH 40
#define TEXTHEIGHT 25
#define MAX_CURTAIN 24

typedef struct {
	XtCallbackList up;
	XtCallbackList down;
	XtCallbackList right;
	XtCallbackList left;
	XtCallbackList cancel;
	XtCallbackList confirm;
	XtCallbackList escape;
	XtCallbackList speedctl;
	XtCallbackList motion;
	XtCallbackList die;
	GC gc;
	XFontStruct *font;
	Pixmap pixmap[2];	/* main/sub graphic screen */
	char text[TEXTWIDTH][TEXTHEIGHT][2];	/* text screen */
	int text_attr[TEXTWIDTH][TEXTHEIGHT];	/* text attributes
						   (only for text color) */
	char saved_text[TEXTWIDTH][TEXTHEIGHT][2];
	int saved_text_attr[TEXTWIDTH][TEXTHEIGHT];
	Boolean inmenu;
	Boolean texton;
	GC textgc[NTXTCOLS];
	Colormap colormap;
	XColor color[NCOLORS];
	XtWorkProcId workprocid;
	XtIntervalId timer;
	int count;		/* used by fade-in etc. */
	int speed;		/* used by fade-in etc. */
	XColor targetcolor[NCOLORS];
	XColor fadestartcolor[NCOLORS];
	XColor fadeendcolor[NCOLORS];
	Boolean curtain_opened;		/* curtain is opened or not */
	Boolean curtain_moving;
	int curtain_count;		/* curtain is opened or not */
	int current_display;
	XRectangle *curtain_rect;
	int curtain_rect_num;
	Boolean display_flipped;
	anim_t anim;
} RookiesPart;

typedef struct _RookiesRec {
	CorePart core;
	RookiesPart rookies;
} RookiesRec;

typedef struct {
	int dummy;
} RookiesClassPart;

typedef struct _RookiesClassRec {
	CoreClassPart core_class;
	RookiesClassPart Rookies_class;
} RookiesClassRec;

extern RookiesClassRec rookiesClassRec;

#endif
