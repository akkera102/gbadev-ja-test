#ifndef _Rookies_H_
#define _Rookies_H_

typedef struct _RookiesRec *RookiesWidget;
typedef struct _RookiesClassRec *RookiesWidgetClass;

extern WidgetClass rookiesWidgetClass;

extern int RookiesGetWidth(Widget);
extern int RookiesGetHeight(Widget);
extern XFontStruct *RookiesGetFontStruct(Widget);
extern void RookiesSetPixmap(Widget, Pixmap, int);
extern Pixmap RookiesGetPixmap(Widget, int);
extern void RookiesClearPixmap(Widget, int, unsigned long);
extern void RookiesInitialize(Widget);

#endif
