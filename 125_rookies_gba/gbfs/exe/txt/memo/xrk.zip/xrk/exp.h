#ifndef _exp_h_
#define _exp_h_

void expand_file(FILE *, unsigned char *, int);

#endif
