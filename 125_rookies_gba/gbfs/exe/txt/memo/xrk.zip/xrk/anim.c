#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <X11/Xos.h>
#include <X11/Xlib.h>
#include <X11/IntrinsicP.h>
#include "anim.h"
#include "rookiesP.h"

unsigned int hoge[16] = {
#ifdef RK_LITTLE_ENDIAN
  0x00000000, 0x01000000, 0x00010000, 0x01010000,
  0x00000100, 0x01000100, 0x00010100, 0x01010100,
  0x00000001, 0x01000001, 0x00010001, 0x01010001,
  0x00000101, 0x01000101, 0x00010101, 0x01010101,
#else
  0x00000000, 0x00000001, 0x00000100, 0x00000101,
  0x00010000, 0x00010001, 0x00010100, 0x00010101,
  0x01000000, 0x01000001, 0x01000100, 0x01000101,
  0x01010000, 0x01010001, 0x01010100, 0x01010101,
#endif
};

extern unsigned char *idx_buf, *pix_buf;

void expand_animation(Widget w, int vheight, int top, int bottom, int speed)
{
  int i, j;
  int idx_ind, pix_ind;
  int c, d, e, f;
  int x, y;
  int len;
  unsigned char ppp, qqq;
  int width, height, byte_width;
  int size;
  unsigned char *data;
  unsigned char *p;
  anim_t anim;
  Display *display;
  Visual *visual;
  XImage *ximage;
  int screen;
  int depth;
  GC gc;
  RookiesWidget rw;

  rw = (RookiesWidget)w;

  if (rw->rookies.anim != NULL) {
    rw->rookies.anim->current = rw->rookies.anim->top = top;
    rw->rookies.anim->bottom = bottom;
    rw->rookies.anim->speed = speed;
    return;
  }
  display = XtDisplay(rw);
  visual = DefaultVisual(display, DefaultScreen(display));
  screen = DefaultScreen(display);
  depth = DefaultDepth(display, screen);
  gc = DefaultGC(display, screen);

  anim = (anim_t)malloc(sizeof(struct _anim_t));

  /* skip magic numbers */
#if 0
  for (idx_ind = 0; idx_ind < 4; idx_ind += 4) {
    c = idx_buf[idx_ind] + (idx_buf[idx_ind + 1] << 8);
    d = idx_buf[idx_ind + 2] + (idx_buf[idx_ind + 3] << 8);
  }
#else
  idx_ind = 4;
#endif

  /* palette parameters */
#define FACTOR 0x1111
  for (j = 0; j < 0x10; idx_ind += 3, j++) {
    anim->color[j].green = idx_buf[idx_ind] * FACTOR;
    anim->color[j].red = idx_buf[idx_ind + 1] * FACTOR;
    anim->color[j].blue = idx_buf[idx_ind + 2] * FACTOR;
    anim->color[j].flags = DoRed|DoGreen|DoBlue;
  }

  /* misc. parameters */
  c = idx_buf[idx_ind] + (idx_buf[idx_ind + 1] << 8);
  d = idx_buf[idx_ind + 2] + (idx_buf[idx_ind + 3] << 8);
  e = idx_buf[idx_ind + 4] + (idx_buf[idx_ind + 5] << 8);
  f = idx_buf[idx_ind + 6] + (idx_buf[idx_ind + 7] << 8);
  idx_ind += 8;

  byte_width = e - c;
  height = (f - d) / 0x50;
  width = byte_width * 8;
  size = width * height;

  data = (unsigned char *)malloc(size);
  memset(data, '\0', size);

  for (x = 0, p = data; x < width; x += 8, p += 8) {
    unsigned int hrp, hbp, hgp, hip;
    unsigned int lrp, lbp, lgp, lip;
    unsigned int hz, lz;
    unsigned char *q;
    for (y = 0, q = p; y < height; y += len) {
      len = 1;
      ppp = idx_buf[idx_ind++];
      pix_ind = (unsigned char)(ppp << 2);
      if ((ppp & 0x80) == 0)
	pix_ind += (idx_buf[idx_ind++] << 8);
      if ((ppp & 0x40) != 0) {
        qqq = idx_buf[idx_ind++];
	len = (qqq == 0) ? (idx_buf[idx_ind++] + 0x100) : qqq;
      }
      hrp = hoge[pix_buf[pix_ind] >> 4];
      lrp = hoge[pix_buf[pix_ind] & 0xf];
      hbp = hoge[pix_buf[pix_ind + 1] >> 4];
      lbp = hoge[pix_buf[pix_ind + 1] & 0xf];
      hgp = hoge[pix_buf[pix_ind + 2] >> 4];
      lgp = hoge[pix_buf[pix_ind + 2] & 0xf];
      hip = hoge[pix_buf[pix_ind + 3] >> 4];
      lip = hoge[pix_buf[pix_ind + 3] & 0xf];
      hz = (hip << 3) | (hgp << 2) | (hbp << 1) | hrp;
      lz = (lip << 3) | (lgp << 2) | (lbp << 1) | lrp;
      for (i = 0; i < len; i++, q += width) {
	if (y + i < height) {
#if defined(RK_LITTLE_ENDIAN) || defined(RK_BIG_ENDIAN)
	  ((unsigned int *)q)[0] = hz;
	  ((unsigned int *)q)[1] = lz;
#else
	q[0] = (unsigned char)(hz >> 24);
	q[1] = (unsigned char)(hz >> 16);
	q[2] = (unsigned char)(hz >> 8);
	q[3] = (unsigned char)hz;
	q[4] = (unsigned char)(lz >> 24);
	q[5] = (unsigned char)(lz >> 16);
	q[6] = (unsigned char)(lz >> 8);
	q[7] = (unsigned char)lz;
#endif
	}
      }
    }
  }
  anim->width = width;
  anim->height = height;
  anim->vheight = vheight;
  anim->current = anim->top = top;
  anim->bottom = bottom;
  anim->speed = speed;
  ximage = XCreateImage(display, visual, depth, ZPixmap,
			      0, 0, width, height, 8, 0);
  ximage->data = data;
  XInitImage(ximage);

  for (i = 0; i < height; i++)
    for (j = 0; j < width; j++)
      XPutPixel(ximage, j, i, rw->rookies.color[XGetPixel(ximage, j, i)].pixel);

  anim->pixmap = XCreatePixmap(display, XtWindow(rw), width, height, depth);
  XPutImage(display, anim->pixmap, gc, ximage, 0, 0, 0, 0, width, height);

  XDestroyImage(ximage);

  rw->rookies.anim = anim;
}

void free_animation(Widget w)
{
  RookiesWidget rw = (RookiesWidget)w;
  Display *display = XtDisplay(rw);
  XFreePixmap(display, rw->rookies.anim->pixmap);
  free(rw->rookies.anim);
  rw->rookies.anim = NULL;
}
