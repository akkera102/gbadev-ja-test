#include "manage.h"


//---------------------------------------------------------------------------
int main(void)
{
	ManageInit();
	ManageExec();

	return 0;
}
