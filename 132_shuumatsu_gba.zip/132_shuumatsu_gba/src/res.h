#ifndef __RES_H__
#define __RES_H__


// ani
// EMPTY


// fnt
#include "res/fnt_k12x10.h"
extern const unsigned char cct_sjis_bin[];
extern const unsigned short tbl_spr1d_bin[];


// bg
// EMPTY


// spr
#include "res/spr_cursor.h"


// snd
// EMPTY


#endif
